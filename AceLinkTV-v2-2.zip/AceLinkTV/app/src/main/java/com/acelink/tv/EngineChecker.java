package com.acelink.tv;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.UUID;

/**
 * Comprueba si un enlace funciona preguntando al motor de Ace Stream (su API HTTP local,
 * normalmente en 127.0.0.1:6878). Abre una sesión de prueba, mira si empieza a descargar
 * datos y la cierra. Hace falta que el motor esté en marcha (app Ace Stream Media abierta).
 */
final class EngineChecker {

    enum Result { OK, DOWN, ENGINE_UNAVAILABLE }

    interface Cancel {
        boolean isCancelled();
    }

    private EngineChecker() {
    }

    /** "127.0.0.1:6878" -> "http://127.0.0.1:6878" */
    static String normalizeBase(String engine) {
        String s = engine == null ? "" : engine.trim();
        if (s.isEmpty()) s = "127.0.0.1:6878";
        String low = s.toLowerCase(Locale.ROOT);
        if (!low.startsWith("http://") && !low.startsWith("https://")) s = "http://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** ¿Hay algo escuchando en esa dirección? */
    static boolean reachable(String base) {
        Socket socket = new Socket();
        try {
            URL u = new URL(base);
            int port = u.getPort() != -1 ? u.getPort() : u.getDefaultPort();
            socket.connect(new InetSocketAddress(u.getHost(), port), 3000);
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
                // nada que hacer
            }
        }
    }

    static Result check(AceLink link, String base, long timeoutMs, Cancel cancel) {
        String param;
        try {
            param = link.kind == AceLink.Kind.CONTENT_ID
                    ? "id=" + link.value
                    : "url=" + URLEncoder.encode(link.value, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return Result.DOWN;
        }
        String start = base + "/ace/getstream?" + param + "&format=json&pid=" + UUID.randomUUID();

        String commandUrl = "";
        try {
            String body = Http.get(start, 5000, (int) Math.min(timeoutMs, 30000), 65536, false);
            JSONObject root = new JSONObject(body);
            if (hasError(root)) return Result.DOWN;
            JSONObject response = root.optJSONObject("response");
            if (response == null) return Result.DOWN;
            String statUrl = response.optString("stat_url", "");
            commandUrl = response.optString("command_url", "");
            if (statUrl.isEmpty()) return Result.DOWN;

            long deadline = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < deadline) {
                if (cancel.isCancelled()) return Result.DOWN;
                String statBody = Http.get(statUrl, 5000, 8000, 65536, false);
                JSONObject stat = new JSONObject(statBody).optJSONObject("response");
                if (stat != null) {
                    String status = stat.optString("status", "");
                    int peers = stat.optInt("peers", 0);
                    int speed = stat.optInt("speed_down", 0);
                    if ("dl".equals(status)) return Result.OK;
                    if (("prebuf".equals(status) || "buf".equals(status)) && peers > 0 && speed > 0) {
                        return Result.OK;
                    }
                    if ("err".equals(status) || "error".equals(status)) return Result.DOWN;
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return Result.DOWN;
                }
            }
            return Result.DOWN;
        } catch (SocketTimeoutException e) {
            return Result.DOWN;        // el motor responde pero el contenido no aparece
        } catch (JSONException e) {
            return Result.DOWN;
        } catch (IOException e) {
            return Result.ENGINE_UNAVAILABLE;
        } finally {
            stopSession(commandUrl);
        }
    }

    private static boolean hasError(JSONObject root) {
        if (root.isNull("error")) return false;
        String e = root.optString("error", "");
        return !e.isEmpty() && !"null".equals(e);
    }

    private static void stopSession(String commandUrl) {
        if (commandUrl == null || commandUrl.isEmpty()) return;
        try {
            String sep = commandUrl.contains("?") ? "&" : "?";
            Http.get(commandUrl + sep + "method=stop", 3000, 5000, 4096, false);
        } catch (IOException ignored) {
            // si no se puede cerrar, el motor la cierra solo por inactividad
        }
    }
}
