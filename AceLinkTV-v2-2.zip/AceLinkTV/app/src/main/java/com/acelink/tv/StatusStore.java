package com.acelink.tv;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Recuerda el último resultado de la comprobación de cada enlace, para mostrarlo al abrir la app. */
final class StatusStore {

    static final int UNKNOWN = 0;
    static final int OK = 1;
    static final int DOWN = 2;
    static final int CHECKING = 3;   // solo en pantalla, nunca se guarda

    private final SharedPreferences prefs;

    StatusStore(Context context) {
        prefs = context.getSharedPreferences("acelink_status", Context.MODE_PRIVATE);
    }

    int get(String key) {
        String v = prefs.getString(key, "");
        if (v.startsWith("1:")) return OK;
        if (v.startsWith("2:")) return DOWN;
        return UNKNOWN;
    }

    void put(String key, int state) {
        prefs.edit().putString(key, state + ":" + System.currentTimeMillis()).apply();
    }

    /** Borra los resultados de enlaces que ya no están en la lista. */
    void keepOnly(Set<String> keys) {
        List<String> stale = new ArrayList<>();
        for (String k : prefs.getAll().keySet()) {
            if (!keys.contains(k)) stale.add(k);
        }
        if (stale.isEmpty()) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (String k : stale) editor.remove(k);
        editor.apply();
    }
}
