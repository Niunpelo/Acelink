# AceLink para Android TV (versión 2)

App sencilla para Android TV / Google TV / Fire TV: escribes (o eliges de tu lista) un enlace
`acestream://…` y se abre en **Ace Stream Media**, que es quien reproduce el vídeo.

Novedades de la versión 2:

- **Mi lista en línea:** los enlaces viven en un archivo de texto tuyo (un Gist de GitHub) que
  editas desde el ordenador o el móvil. En la app pulsas **Actualizar lista** y se descargan.
- **Comprobación de enlaces:** un círculo junto a cada enlace: verde = funciona, rojo = no funciona,
  naranja = revisando, gris = sin revisar.
- **Firma fija:** las actualizaciones se instalan encima de la anterior, sin desinstalar
  (solo hay que desinstalar la versión 1 una vez, porque tenía otra firma).

La app no incluye ningún canal ni lista de enlaces: los pones tú. App independiente, no afiliada a Ace Stream.

## Formato de tu lista

Un archivo de texto, una línea por enlace (mira `enlaces-ejemplo.txt`):

```
Nombre del canal | acestream://ID_DE_40_CARACTERES
```

También vale `acestream://ID Nombre`, `Nombre - acestream://ID`, el ID suelto y listas M3U.
Las líneas que empiezan por `#` son comentarios.

## Crear tu lista (una vez)

1. Entra en <https://gist.github.com> con tu cuenta (sirve en ordenador y móvil).
2. Nombre del archivo: `enlaces.txt`. Escribe tus enlaces con el formato de arriba.
3. Pulsa **Create secret gist** (secreto: solo lo ve quien tenga la dirección).
4. En el gist pulsa **Raw** y copia la dirección. Será como
   `https://gist.githubusercontent.com/USUARIO/ID/raw/CODIGO_LARGO/enlaces.txt`.
   **Borra la parte `CODIGO_LARGO/`**, para que quede `…/raw/enlaces.txt` y apunte siempre
   a la última versión.
5. Para cambiar la lista: abre el gist, **Edit**, guarda. En la tele pulsa **Actualizar lista**.

## En la app

1. **Ajustes de la lista y del motor** → pega la dirección de tu lista → Guardar.
2. **Actualizar lista** descarga los enlaces (se guardan en la tele, así que sin internet
   se sigue viendo la última lista).
3. **Comprobar enlaces** revisa uno a uno con el motor de Ace Stream. Para esto hace falta que la app
   **Ace Stream Media esté abierta** (el motor escucha en `127.0.0.1:6878`; si lo usas en otro equipo,
   cambia la dirección en Ajustes). Cada enlace se revisa hasta 25 segundos.
4. Pulsa un enlace para reproducirlo.

## Conseguir el APK

El APK se compila gratis en GitHub (ver `.github/workflows/build-apk.yml`): sube el zip a tu
repositorio y la compilación arranca sola; el APK queda en **Releases**.
Alternativa: abrir esta carpeta en Android Studio y elegir **Build → Build APK(s)**.

## Estructura

- `MainActivity.java` — pantalla, ajustes, lista y círculos.
- `AceLink.java` — interpreta un enlace.
- `ListParser.java` — lee tu archivo de lista.
- `EngineChecker.java` — comprueba un enlace con el motor de Ace Stream.
- `Http.java`, `LinkStore.java`, `StatusStore.java` — descarga y almacenamiento local.
- `app/acelink.jks` — firma fija personal para poder actualizar la app (no es secreta).
