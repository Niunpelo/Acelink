package com.acelink.tv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Descarga de texto por HTTP(S), sin librerías externas. Se usa siempre fuera del hilo principal. */
final class Http {

    private Http() {
    }

    /**
     * @param failOnHttpError si es true, un código 4xx/5xx lanza IOException; si es false se devuelve el cuerpo
     *                        del error (el motor de Ace Stream responde errores en JSON).
     */
    static String get(String url, int connectMs, int readMs, int maxBytes, boolean failOnHttpError)
            throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(connectMs);
        c.setReadTimeout(readMs);
        c.setRequestProperty("User-Agent", "AceLink/2.0");
        try {
            int code = c.getResponseCode();
            if (code >= 400 && failOnHttpError) throw new IOException("HTTP " + code);
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return "";
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > maxBytes) throw new IOException("respuesta demasiado grande");
                }
                return out.toString("UTF-8");
            } finally {
                in.close();
            }
        } finally {
            c.disconnect();
        }
    }
}
