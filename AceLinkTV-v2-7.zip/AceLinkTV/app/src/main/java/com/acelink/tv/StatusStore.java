package com.acelink.tv;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Recuerda el último resultado de la comprobación de cada enlace, para mostrarlo al abrir la app. */
final class StatusStore {

    static final int UNKNOWN = 0;
    static final int OK = 1;
    static final int DOWN = 2;
    static final int CHECKING = 3;   // solo en pantalla, nunca se guarda

    private final SharedPreferences prefs;

    StatusStore(Context context) {
        prefs = context.getSharedPreferences("acelink_status", Context.MODE_PRIVATE);
    }

    int get(String key) {
        String v = prefs.getString(key, "");
        if (v.startsWith("1:")) return OK;
        if (v.startsWith("2:")) return DOWN;
        return UNKNOWN;
    }

    void put(String key, int state) {
        prefs.edit().putString(key, state + ":" + System.currentTimeMillis()).apply();
    }

    /**
     * Guarda un enlace que funciona junto con su calidad. La nota se suaviza con la anterior
     * (60 % nueva + 40 % antigua) para que una sola prueba mala o buena no cambie el orden de golpe.
     * Formato: estado:hora:nota:arranqueMs:peers:KBps
     */
    void putResult(String key, int state, Quality q) {
        int score = q.score;
        int old = getScore(key);
        if (old >= 0) score = (int) Math.round(0.6 * q.score + 0.4 * old);
        prefs.edit().putString(key, state + ":" + System.currentTimeMillis() + ":" + score + ":"
                + q.startMs + ":" + q.peers + ":" + q.avgSpeed).apply();
    }

    /** Nota 0-100 de la última prueba, o -1 si no hay. */
    int getScore(String key) {
        String[] p = prefs.getString(key, "").split(":");
        if (p.length < 3) return -1;
        try {
            return Integer.parseInt(p[2]);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Texto corto con la calidad, p. ej. "82/100 · 2,4 s · 31 peers · 640 KB/s"; "" si no hay datos. */
    String detail(String key) {
        String[] p = prefs.getString(key, "").split(":");
        if (p.length < 6 || !p[0].equals("1")) return "";
        try {
            double sec = Long.parseLong(p[3]) / 1000.0;
            return p[2] + "/100 · " + String.format(java.util.Locale.getDefault(), "%.1f", sec)
                    + " s · " + p[4] + " peers · " + p[5] + " KB/s";
        } catch (NumberFormatException e) {
            return "";
        }
    }

    /** Borra los resultados de enlaces que ya no están en la lista. */
    void keepOnly(Set<String> keys) {
        List<String> stale = new ArrayList<>();
        for (String k : prefs.getAll().keySet()) {
            if (!keys.contains(k)) stale.add(k);
        }
        if (stale.isEmpty()) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (String k : stale) editor.remove(k);
        editor.apply();
    }
}
