package com.acelink.tv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Agrupa los enlaces por canal y ordena los de cada canal de mejor a peor. */
final class ChannelGrouper {

    static final class Channel {
        final String key;
        final String name;
        final List<LinkStore.Item> links = new ArrayList<>();

        Channel(String key, String name) {
            this.key = key;
            this.name = name;
        }

        /** El mejor enlace (el primero tras ordenar). */
        LinkStore.Item best() {
            return links.get(0);
        }
    }

    private ChannelGrouper() {
    }

    /** Los canales salen en el orden en que aparecen en tu lista; dentro de cada uno, de mejor a peor. */
    static List<Channel> group(List<LinkStore.Item> items, final StatusStore status) {
        Map<String, Channel> map = new LinkedHashMap<>();
        for (LinkStore.Item item : items) {
            String key = ChannelName.key(item.name);
            String name = ChannelName.display(item.name);
            if (key.isEmpty()) {          // sin nombre: cada enlace va por su cuenta
                key = "id:" + item.link.canonical();
                name = item.link.shortLabel();
            }
            Channel ch = map.get(key);
            if (ch == null) {
                ch = new Channel(key, name);
                map.put(key, ch);
            }
            ch.links.add(item);
        }

        final Map<String, int[]> rank = new LinkedHashMap<>();   // clave del enlace -> {grupo, nota}
        for (Channel ch : map.values()) {
            for (LinkStore.Item it : ch.links) {
                String k = it.link.canonical();
                int state = status.get(k);
                int group = state == StatusStore.OK ? 0 : (state == StatusStore.DOWN ? 2 : 1);
                rank.put(k, new int[]{group, status.getScore(k)});
            }
        }
        Comparator<LinkStore.Item> cmp = new Comparator<LinkStore.Item>() {
            @Override
            public int compare(LinkStore.Item a, LinkStore.Item b) {
                int[] ra = rank.get(a.link.canonical());
                int[] rb = rank.get(b.link.canonical());
                if (ra[0] != rb[0]) return ra[0] < rb[0] ? -1 : 1;     // funcionan > sin revisar > caídos
                return Integer.compare(rb[1], ra[1]);                  // mayor nota primero
            }
        };
        List<Channel> out = new ArrayList<>(map.values());
        for (Channel ch : out) Collections.sort(ch.links, cmp);        // orden estable
        return out;
    }
}
