package com.acelink.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Guarda una lista de enlaces en el propio televisor.
 * Se usa para dos listas distintas: "Recientes" (los que reproduces a mano) y
 * "Mi lista" (la que se descarga de tu dirección en línea).
 */
final class LinkStore {

    static final class Item {
        final String name;
        final AceLink link;

        Item(String name, AceLink link) {
            this.name = name;
            this.link = link;
        }

        String label() {
            return name.isEmpty() ? link.shortLabel() : name;
        }
    }

    private static final String KEY = "items";

    private final SharedPreferences prefs;
    private final int maxItems;

    /** Lista de recientes (máximo 40). */
    LinkStore(Context context) {
        this(context, "acelink_links", 40);
    }

    LinkStore(Context context, String prefsName, int maxItems) {
        this.prefs = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE);
        this.maxItems = maxItems;
    }

    List<Item> load() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                AceLink link = AceLink.parse(o.optString("c", ""));
                if (link != null) out.add(new Item(o.optString("n", ""), link));
            }
        } catch (JSONException e) {
            // Datos dañados: se empieza con la lista vacía.
        }
        return out;
    }

    /** Pone el enlace el primero. Si no se da nombre, conserva el que ya tuviera. */
    void saveOrUpdate(AceLink link, String name) {
        List<Item> items = load();
        String finalName = name == null ? "" : name.trim();
        for (Iterator<Item> it = items.iterator(); it.hasNext(); ) {
            Item existing = it.next();
            if (existing.link.canonical().equals(link.canonical())) {
                if (finalName.isEmpty()) finalName = existing.name;
                it.remove();
            }
        }
        items.add(0, new Item(finalName, link));
        write(items);
    }

    /** Sustituye toda la lista (se usa al actualizar desde internet). */
    void replaceAll(List<Item> items) {
        write(new ArrayList<>(items));
    }

    void remove(AceLink link) {
        List<Item> items = load();
        for (Iterator<Item> it = items.iterator(); it.hasNext(); ) {
            if (it.next().link.canonical().equals(link.canonical())) it.remove();
        }
        write(items);
    }

    private void write(List<Item> items) {
        while (items.size() > maxItems) items.remove(items.size() - 1);
        JSONArray arr = new JSONArray();
        for (Item item : items) {
            try {
                JSONObject o = new JSONObject();
                o.put("n", item.name);
                o.put("c", item.link.canonical());
                arr.put(o);
            } catch (JSONException ignored) {
                // No debería pasar con cadenas normales.
            }
        }
        prefs.edit().putString(KEY, arr.toString()).apply();
    }
}
