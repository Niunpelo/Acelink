package com.acelink.tv;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.UUID;

/**
 * Comprueba si un enlace funciona preguntando al motor de Ace Stream (su API HTTP local,
 * normalmente en 127.0.0.1:6878). Abre una sesión de prueba, mira si empieza a descargar
 * datos y la cierra. Hace falta que el motor esté en marcha (app Ace Stream Media abierta).
 */
final class EngineChecker {

    enum Result { OK, DOWN, ENGINE_UNAVAILABLE }

    /** Resultado de una prueba; quality solo existe si el enlace funciona. */
    static final class Outcome {
        final Result result;
        final Quality quality;

        Outcome(Result result, Quality quality) {
            this.result = result;
            this.quality = quality;
        }
    }

    interface Cancel {
        boolean isCancelled();
    }

    private EngineChecker() {
    }

    /** "127.0.0.1:6878" -> "http://127.0.0.1:6878" */
    static String normalizeBase(String engine) {
        String s = engine == null ? "" : engine.trim();
        if (s.isEmpty()) s = "127.0.0.1:6878";
        String low = s.toLowerCase(Locale.ROOT);
        if (!low.startsWith("http://") && !low.startsWith("https://")) s = "http://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** ¿Hay algo escuchando en esa dirección? */
    static boolean reachable(String base) {
        Socket socket = new Socket();
        try {
            URL u = new URL(base);
            int port = u.getPort() != -1 ? u.getPort() : u.getDefaultPort();
            socket.connect(new InetSocketAddress(u.getHost(), port), 3000);
            return true;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
                // nada que hacer
            }
        }
    }

    static Result check(AceLink link, String base, long timeoutMs, Cancel cancel) {
        return checkDetailed(link, base, timeoutMs, cancel).result;
    }

    static Outcome checkDetailed(AceLink link, String base, long timeoutMs, Cancel cancel) {
        String param;
        try {
            param = link.kind == AceLink.Kind.CONTENT_ID
                    ? "id=" + link.value
                    : "url=" + URLEncoder.encode(link.value, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return new Outcome(Result.DOWN, null);
        }
        final long t0 = System.currentTimeMillis();
        String start = base + "/ace/getstream?" + param + "&format=json&pid=" + UUID.randomUUID();

        String commandUrl = "";
        try {
            String body = Http.get(start, 5000, (int) Math.min(timeoutMs, 30000), 65536, false);
            JSONObject root = new JSONObject(body);
            if (hasError(root)) return new Outcome(Result.DOWN, null);
            JSONObject response = root.optJSONObject("response");
            if (response == null) return new Outcome(Result.DOWN, null);
            String statUrl = response.optString("stat_url", "");
            commandUrl = response.optString("command_url", "");
            if (statUrl.isEmpty()) return new Outcome(Result.DOWN, null);

            long deadline = System.currentTimeMillis() + timeoutMs;
            while (System.currentTimeMillis() < deadline) {
                if (cancel.isCancelled()) return new Outcome(Result.DOWN, null);
                String statBody = Http.get(statUrl, 5000, 8000, 65536, false);
                JSONObject stat = new JSONObject(statBody).optJSONObject("response");
                if (stat != null) {
                    String status = stat.optString("status", "");
                    int peers = stat.optInt("peers", 0);
                    int speed = stat.optInt("speed_down", 0);
                    boolean ready = "dl".equals(status)
                            || (("prebuf".equals(status) || "buf".equals(status)) && peers > 0 && speed > 0);
                    if (ready) {
                        return measure(statUrl, System.currentTimeMillis() - t0, peers, speed, cancel);
                    }
                    if ("err".equals(status) || "error".equals(status)) return new Outcome(Result.DOWN, null);
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return new Outcome(Result.DOWN, null);
                }
            }
            return new Outcome(Result.DOWN, null);
        } catch (SocketTimeoutException e) {
            return new Outcome(Result.DOWN, null);        // el motor responde pero el contenido no aparece
        } catch (JSONException e) {
            return new Outcome(Result.DOWN, null);
        } catch (IOException e) {
            return new Outcome(Result.ENGINE_UNAVAILABLE, null);
        } finally {
            stopSession(commandUrl);
        }
    }

    /**
     * El enlace ya descarga: se miden unos segundos más (5 muestras, una por segundo) para
     * sacar velocidad media, velocidad mínima (estabilidad) y número de peers.
     */
    private static Outcome measure(String statUrl, long startMs, int peers0, int speed0, Cancel cancel) {
        long sum = speed0;
        int min = speed0;
        int n = 1;
        int peers = peers0;
        for (int i = 0; i < 4; i++) {
            if (cancel.isCancelled()) break;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
            try {
                JSONObject st = new JSONObject(Http.get(statUrl, 5000, 8000, 65536, false)).optJSONObject("response");
                if (st == null) break;
                int sp = st.optInt("speed_down", 0);
                sum += sp;
                n++;
                if (sp < min) min = sp;
                peers = Math.max(peers, st.optInt("peers", 0));
            } catch (IOException | JSONException e) {
                break;
            }
        }
        return new Outcome(Result.OK, new Quality(startMs, peers, (int) (sum / n), min));
    }

    private static boolean hasError(JSONObject root) {
        if (root.isNull("error")) return false;
        String e = root.optString("error", "");
        return !e.isEmpty() && !"null".equals(e);
    }

    private static void stopSession(String commandUrl) {
        if (commandUrl == null || commandUrl.isEmpty()) return;
        try {
            String sep = commandUrl.contains("?") ? "&" : "?";
            Http.get(commandUrl + sep + "method=stop", 3000, 5000, 4096, false);
        } catch (IOException ignored) {
            // si no se puede cerrar, el motor la cierra solo por inactividad
        }
    }
}
