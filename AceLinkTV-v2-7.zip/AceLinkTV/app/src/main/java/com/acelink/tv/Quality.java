package com.acelink.tv;

/**
 * Medidas de un enlace que funciona y la nota (0-100) que se saca de ellas.
 * No depende de Android, así que se puede probar con Java normal.
 *
 *  - Arranque (35 pts): cuánto tarda desde que se pide hasta que descarga. ≤3 s = máximo, ≥20 s = 0.
 *  - Velocidad (30 pts): media de descarga durante la prueba. ≥1000 KB/s = máximo.
 *  - Fuentes (20 pts): nº de peers conectados. ≥40 = máximo.
 *  - Estabilidad (15 pts): velocidad mínima / velocidad media durante la prueba.
 */
final class Quality {

    final long startMs;
    final int peers;
    final int avgSpeed;   // KB/s
    final int minSpeed;   // KB/s
    final int score;

    Quality(long startMs, int peers, int avgSpeed, int minSpeed) {
        this.startMs = startMs;
        this.peers = peers;
        this.avgSpeed = avgSpeed;
        this.minSpeed = minSpeed;
        this.score = compute(startMs, peers, avgSpeed, minSpeed);
    }

    static int compute(long startMs, int peers, int avgSpeed, int minSpeed) {
        double start = clamp(1.0 - (startMs - 3000.0) / 17000.0);
        double speed = clamp(avgSpeed / 1000.0);
        double swarm = clamp(peers / 40.0);
        double steady = avgSpeed > 0 ? clamp((double) minSpeed / avgSpeed) : 0.0;
        return (int) Math.round(35 * start + 30 * speed + 20 * swarm + 15 * steady);
    }

    private static double clamp(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
