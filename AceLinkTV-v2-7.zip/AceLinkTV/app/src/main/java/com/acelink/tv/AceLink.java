package com.acelink.tv;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Interpreta lo que el usuario escribe o pega y lo convierte en algo que Ace Stream entiende.
 *
 * Formatos admitidos:
 *  - acestream://<id de 40 caracteres>
 *  - acestream:?content_id=<id>
 *  - el id suelto (40 caracteres hexadecimales)
 *  - http://127.0.0.1:6878/ace/getstream?id=<id>  (se extrae el id)
 *  - una dirección http(s):// de un archivo de transporte (.acelive / .torrent)
 *
 * No depende de Android, así que se puede probar con Java normal.
 */
public final class AceLink {

    public enum Kind { CONTENT_ID, URL }

    private static final Pattern ACESTREAM_SCHEME = Pattern.compile(
            "^acestream:(?://|\\?content_id=)?([0-9a-f]{40})(?:[\\s/?&#].*)?$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    private static final Pattern BARE_ID = Pattern.compile(
            "^([0-9a-f]{40})(?:\\s.*)?$",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    private static final Pattern ENGINE_URL = Pattern.compile(
            "^https?://\\S*[?&](?:id|content_id)=([0-9a-f]{40})(?:&\\S*)?$",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern HTTP_URL = Pattern.compile(
            "^https?://\\S+$", Pattern.CASE_INSENSITIVE);

    public final Kind kind;
    /** En minúsculas si es un id; tal cual si es una URL. */
    public final String value;

    private AceLink(Kind kind, String value) {
        this.kind = kind;
        this.value = value;
    }

    /** Devuelve null si el texto no es un enlace válido. */
    public static AceLink parse(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.isEmpty()) return null;

        Matcher m = ACESTREAM_SCHEME.matcher(s);
        if (m.matches()) return new AceLink(Kind.CONTENT_ID, m.group(1).toLowerCase(Locale.ROOT));

        m = BARE_ID.matcher(s);
        if (m.matches()) return new AceLink(Kind.CONTENT_ID, m.group(1).toLowerCase(Locale.ROOT));

        m = ENGINE_URL.matcher(s);
        if (m.matches()) return new AceLink(Kind.CONTENT_ID, m.group(1).toLowerCase(Locale.ROOT));

        if (HTTP_URL.matcher(s).matches()) return new AceLink(Kind.URL, s);

        return null;
    }

    /** Forma normalizada, que además se puede volver a interpretar con parse(). */
    public String canonical() {
        return kind == Kind.CONTENT_ID ? "acestream://" + value : value;
    }

    /** Texto corto para mostrar en la lista cuando el enlace no tiene nombre. */
    public String shortLabel() {
        if (kind == Kind.CONTENT_ID) {
            return "acestream://" + value.substring(0, 8) + "…" + value.substring(value.length() - 4);
        }
        return value.length() > 48 ? value.substring(0, 47) + "…" : value;
    }
}
