package com.acelink.tv;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Decide qué enlaces son "el mismo canal". Dos nombres son el mismo canal si, tras quitar
 * mayúsculas, tildes, lo que va entre paréntesis/corchetes y etiquetas como HD, 1080p,
 * "opción 2", "fuente 3", "backup"…, quedan iguales.
 *
 *   "DAZN 1 (Fuente 2)"  ->  dazn 1
 *   "DAZN 1 HD"          ->  dazn 1
 *   "Dazn 1 - opción 3"  ->  dazn 1
 *   "Movistar Laliga op.2" -> movistar laliga   ("op.2", "op 2", "op2", "opc. 2"…)
 *   "DAZN 2"             ->  dazn 2      (el número del canal se respeta)
 *
 * No depende de Android, así que se puede probar con Java normal.
 */
final class ChannelName {

    private static final Pattern BRACKETS = Pattern.compile("\\([^)]*\\)|\\[[^\\]]*\\]|\\{[^}]*\\}");
    private static final Pattern TAGS = Pattern.compile(
            "(?i)(?:^|[\\s\\-–—_|/,])(?:"
                    + "(?:opci[oó]n|opcion|opc|option|op|enlace|link|fuente|source|src|mirror|espejo|calidad)[\\s.#:_\\-]*\\d*"
                    + "|#\\d+"
                    + "|alt|backup|respaldo|reserva|multi|multiaudio"
                    + "|u?hd|fhd|sd|4k|8k|2160p?|1080[pi]?|720p?|576p?|480p?|360p?"
                    + ")(?=$|[\\s\\-–—_|/,])");
    private static final Pattern EDGE_JUNK = Pattern.compile("^[\\s\\-–—:,;|/_]+|[\\s\\-–—:,;|/_]+$");
    private static final Pattern SPACES = Pattern.compile("\\s+");
    private static final Pattern NOT_KEY = Pattern.compile("[^a-z0-9+ ]");

    private ChannelName() {
    }

    /** Nombre limpio para mostrar como título del canal ("" si no queda nada). */
    static String display(String raw) {
        if (raw == null) return "";
        String s = BRACKETS.matcher(raw).replaceAll(" ");
        String prev;
        do {
            prev = s;
            s = TAGS.matcher(s).replaceAll(" ");
        } while (!s.equals(prev));
        s = SPACES.matcher(s).replaceAll(" ");
        return EDGE_JUNK.matcher(s).replaceAll("").trim();
    }

    /** Clave de comparación: minúsculas, sin tildes ni símbolos. "" si no hay nombre. */
    static String key(String raw) {
        String s = display(raw).toLowerCase(Locale.ROOT);
        s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        s = NOT_KEY.matcher(s).replaceAll(" ");
        return SPACES.matcher(s).replaceAll(" ").trim();
    }
}
