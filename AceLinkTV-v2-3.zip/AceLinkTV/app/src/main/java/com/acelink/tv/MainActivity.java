package com.acelink.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pantalla única:
 *  - izquierda: escribir un enlace a mano y reproducirlo, y los ajustes;
 *  - derecha: "Mi lista" (descargada de tu dirección en línea, con un círculo de color que indica
 *    si cada enlace funciona) y "Recientes".
 *
 * La reproducción la hace la app Ace Stream Media; la comprobación usa su motor local.
 * La interfaz se construye por código para no depender de más archivos de diseño.
 */
public class MainActivity extends Activity {

    private static final int COLOR_BG = 0xFF0F141A;
    private static final int COLOR_SURFACE = 0xFF1C2630;
    private static final int COLOR_PRIMARY = 0xFF2E6FD8;
    private static final int COLOR_ACCENT = 0xFFFF8A1F;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_MUTED = 0xFFA9B4C0;

    private static final int DOT_GREY = 0xFF6F7C89;
    private static final int DOT_GREEN = 0xFF2ECC71;
    private static final int DOT_RED = 0xFFE5484D;
    private static final int DOT_ORANGE = 0xFFFF9F1A;

    private static final String SETTINGS = "acelink_settings";
    private static final String KEY_USE_ACE_PLAYER = "use_ace_player";
    private static final String KEY_LIST_URL = "list_url";
    private static final String KEY_ENGINE = "engine";
    private static final String KEY_AUTO = "auto_check";
    private static final String KEY_UPDATED = "list_updated";

    private static final String DEFAULT_ENGINE = "127.0.0.1:6878";
    private static final long CHECK_TIMEOUT_MS = 25000;

    private LinkStore recentStore;
    private LinkStore listStore;
    private StatusStore statusStore;
    private SharedPreferences settings;

    private EditText linkInput;
    private EditText nameInput;
    private CheckBox acePlayerCheck;
    private LinearLayout listBox;
    private TextView statusText;
    private Button updateButton;
    private Button checkButton;

    /** Círculo de color de cada enlace de "Mi lista", por enlace normalizado. */
    private final Map<String, View> dots = new HashMap<>();
    /** Enlaces que están pendientes de revisar o revisándose ahora (círculo naranja). */
    private final Set<String> checkingKeys = new HashSet<>();
    /** Canales con sus enlaces desplegados en pantalla. */
    private final Set<String> expanded = new HashSet<>();

    private final ExecutorService checkExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean checkCancelled;
    private volatile boolean destroyed;
    private boolean checking;
    private boolean updating;

    /** Factor de escala de la interfaz (1 = televisi\u00f3n normal; menos en pantallas peque\u00f1as). */
    private float uiScale = 1f;
    /** Pantalla ancha pero baja (m\u00f3vil en horizontal): se quitan textos de ayuda para que todo quepa. */
    private boolean compact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recentStore = new LinkStore(this);
        listStore = new LinkStore(this, "acelink_list", 500);
        statusStore = new StatusStore(this);
        settings = getSharedPreferences(SETTINGS, MODE_PRIVATE);
        setContentView(buildUi());
        refreshList();
        refreshStatusLine();
        autoStart();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        checkCancelled = true;
        checkExecutor.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ Interfaz

    private View buildUi() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float widthDp = dm.widthPixels / dm.density;
        float heightDp = dm.heightPixels / dm.density;
        boolean narrow = widthDp < 700f;
        // Pantalla ancha: se reduce todo en proporci\u00f3n si es m\u00e1s peque\u00f1a que una tele (960 x 540 dp).
        uiScale = narrow ? 1f : Math.max(0.7f, Math.min(1f, Math.min(heightDp / 540f, widthDp / 960f)));
        compact = !narrow && uiScale < 0.85f;

        LinearLayout left = buildLeftPanel();
        LinearLayout right = buildRightPanel(!narrow);

        if (narrow) {
            // M\u00f3vil en vertical: una sola columna con desplazamiento.
            LinearLayout column = new LinearLayout(this);
            column.setOrientation(LinearLayout.VERTICAL);
            column.setBackgroundColor(COLOR_BG);
            column.setPadding(dp(16), dp(16), dp(16), dp(24));
            column.addView(left, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rightParams.topMargin = dp(24);
            column.addView(right, rightParams);

            ScrollView page = new ScrollView(this);
            page.setBackgroundColor(COLOR_BG);
            page.addView(column);
            return page;
        }

        // Televisi\u00f3n o pantalla ancha: dos columnas. La de la izquierda se desplaza si no cabe todo.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(COLOR_BG);
        root.setPadding(dp(48), dp(32), dp(48), dp(32));

        ScrollView leftScroll = new ScrollView(this);
        leftScroll.addView(left);
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        leftParams.rightMargin = dp(32);
        root.addView(leftScroll, leftParams);
        root.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f));
        return root;
    }

    /** Escribir el enlace, reproducir y ajustes. */
    private LinearLayout buildLeftPanel() {
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);

        left.addView(label("AceLink", 36, COLOR_TEXT, true));
        if (!compact) {
            left.addView(label("Escribe o pega un enlace acestream:// (o solo el ID de 40 caracteres).", 18, COLOR_MUTED, false), topMargin(8));
        }

        linkInput = makeInput("acestream://\u2026");
        linkInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                play();
                return true;
            }
            return false;
        });
        left.addView(linkInput, topMargin(24));

        nameInput = makeInput("Nombre (opcional)");
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        nameInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        nameInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                play();
                return true;
            }
            return false;
        });
        left.addView(nameInput, topMargin(12));

        Button playButton = makeButton("Reproducir", COLOR_PRIMARY);
        playButton.setGravity(Gravity.CENTER);
        playButton.setOnClickListener(v -> play());
        left.addView(playButton, topMargin(20));

        acePlayerCheck = new CheckBox(this);
        acePlayerCheck.setText("Usar el reproductor de Ace Stream (recomendado)");
        acePlayerCheck.setTextColor(COLOR_TEXT);
        acePlayerCheck.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(18));
        acePlayerCheck.setChecked(settings.getBoolean(KEY_USE_ACE_PLAYER, true));
        acePlayerCheck.setFocusable(true);
        acePlayerCheck.setBackground(focusBackground(0x00000000));
        acePlayerCheck.setPadding(dp(12), dp(10), dp(12), dp(10));
        acePlayerCheck.setOnCheckedChangeListener((buttonView, isChecked) ->
                settings.edit().putBoolean(KEY_USE_ACE_PLAYER, isChecked).apply());
        left.addView(acePlayerCheck, topMargin(16));

        Button settingsButton = makeButton("Ajustes de la lista y del motor", COLOR_SURFACE);
        settingsButton.setOnClickListener(v -> showSettings());
        left.addView(settingsButton, topMargin(16));

        if (!compact) {
            left.addView(label("Necesitas tener instalada la app Ace Stream Media en esta televisi\u00f3n. "
                    + "Si no la tienes, esta app te avisar\u00e1.", 15, COLOR_MUTED, false), topMargin(16));
        }
        return left;
    }

    /** Mi lista (con c\u00edrculos de color) y Recientes. */
    private LinearLayout buildRightPanel(boolean listScrollsInside) {
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        right.addView(label("Mi lista", 24, COLOR_TEXT, true));
        statusText = label("", 15, COLOR_MUTED, false);
        right.addView(statusText, topMargin(4));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        updateButton = makeButton("Actualizar lista", COLOR_PRIMARY);
        updateButton.setGravity(Gravity.CENTER);
        updateButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(17));
        updateButton.setOnClickListener(v -> updateList(true, false));
        actions.addView(updateButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        checkButton = makeButton("Comprobar enlaces", COLOR_SURFACE);
        checkButton.setGravity(Gravity.CENTER);
        checkButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(17));
        checkButton.setOnClickListener(v -> {
            if (checking) {
                checkCancelled = true;
                statusText.setText("Parando\u2026");
            } else {
                startCheck(false);
            }
        });
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        checkParams.leftMargin = dp(8);
        actions.addView(checkButton, checkParams);
        right.addView(actions, topMargin(12));

        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        addLegendItem(legend, DOT_GREEN, "Funciona");
        addLegendItem(legend, DOT_RED, "No funciona");
        addLegendItem(legend, DOT_ORANGE, "Revisando");
        addLegendItem(legend, DOT_GREY, "Sin revisar");
        right.addView(legend, topMargin(12));

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        if (listScrollsInside) {
            ScrollView scroll = new ScrollView(this);
            scroll.addView(listBox, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            scrollParams.topMargin = dp(12);
            right.addView(scroll, scrollParams);
        } else {
            right.addView(listBox, topMargin(12));
        }
        return right;
    }

    private void addLegendItem(LinearLayout legend, int color, String text) {
        View dot = new View(this);
        dot.setBackground(circle(color));
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(12), dp(12));
        dotParams.rightMargin = dp(6);
        legend.addView(dot, dotParams);
        TextView t = label(text, 14, COLOR_MUTED, false);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textParams.rightMargin = dp(16);
        legend.addView(t, textParams);
    }

    private void refreshList() {
        listBox.removeAllViews();
        dots.clear();

        List<LinkStore.Item> mine = listStore.load();
        listBox.addView(label("Mi lista (" + ChannelGrouper.group(mine, statusStore).size() + " canales · "
                + mine.size() + " enlaces)", 20, COLOR_TEXT, true));
        if (mine.isEmpty()) {
            listBox.addView(label("Todavía no hay enlaces. Escribe la dirección de tu lista en Ajustes "
                    + "y pulsa «Actualizar lista».", 16, COLOR_MUTED, false), topMargin(8));
        }
        for (final ChannelGrouper.Channel ch : ChannelGrouper.group(mine, statusStore)) {
            final boolean open = expanded.contains(ch.key);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            View chDot = new View(this);
            setDot(chDot, channelState(ch));
            LinearLayout.LayoutParams chDotParams = new LinearLayout.LayoutParams(dp(18), dp(18));
            chDotParams.rightMargin = dp(12);
            row.addView(chDot, chDotParams);

            int n = ch.links.size();
            Button play = makeButton(ch.name + (n > 1 ? "  ·  " + n + " enlaces" : ""), COLOR_SURFACE);
            play.setSingleLine(true);
            play.setEllipsize(android.text.TextUtils.TruncateAt.END);
            play.setOnClickListener(v -> launch(ch.best().link));   // el mejor enlace del canal
            row.addView(play, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (n > 1) {
                Button more = makeButton(open ? "▲" : "▼", COLOR_SURFACE);
                more.setGravity(Gravity.CENTER);
                more.setOnClickListener(v -> {
                    if (!expanded.remove(ch.key)) expanded.add(ch.key);
                    refreshList();
                });
                LinearLayout.LayoutParams moreParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                moreParams.leftMargin = dp(8);
                row.addView(more, moreParams);
            }
            listBox.addView(row, topMargin(8));

            if (!open) continue;
            int pos = 0;
            for (final LinkStore.Item item : ch.links) {
                pos++;
                final String key = item.link.canonical();
                LinearLayout sub = new LinearLayout(this);
                sub.setOrientation(LinearLayout.HORIZONTAL);
                sub.setGravity(Gravity.CENTER_VERTICAL);
                sub.setPadding(dp(30), 0, 0, 0);

                View dot = new View(this);
                setDot(dot, stateOf(key));
                dots.put(key, dot);
                LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(14), dp(14));
                dotParams.rightMargin = dp(10);
                sub.addView(dot, dotParams);

                String detail = statusStore.detail(key);
                Button b = makeButton("#" + pos + "  " + item.label() + (detail.isEmpty() ? "" : "\n" + detail),
                        COLOR_SURFACE);
                b.setOnClickListener(v -> launch(item.link));
                sub.addView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                listBox.addView(sub, topMargin(4));
            }
        }

        List<LinkStore.Item> recents = recentStore.load();
        if (!recents.isEmpty()) {
            listBox.addView(label("Recientes", 20, COLOR_TEXT, true), topMargin(24));
        }
        for (final LinkStore.Item item : recents) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            Button open = makeButton(item.label(), COLOR_SURFACE);
            open.setSingleLine(true);
            open.setEllipsize(android.text.TextUtils.TruncateAt.END);
            open.setOnClickListener(v -> launch(item.link));
            row.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button delete = makeButton("Borrar", COLOR_SURFACE);
            delete.setGravity(Gravity.CENTER);
            delete.setOnClickListener(v -> {
                recentStore.remove(item.link);
                refreshList();
                focusFirstRowOrInput();
            });
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            deleteParams.leftMargin = dp(8);
            row.addView(delete, deleteParams);

            listBox.addView(row, topMargin(8));
        }
    }

    private void focusFirstRowOrInput() {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View child = listBox.getChildAt(i);
            if (child instanceof LinearLayout) {
                LinearLayout row = (LinearLayout) child;
                for (int j = 0; j < row.getChildCount(); j++) {
                    if (row.getChildAt(j) instanceof Button && row.getChildAt(j).requestFocus()) return;
                }
            }
        }
        linkInput.requestFocus();
    }

    private void refreshStatusLine() {
        int n = listStore.load().size();
        String url = settings.getString(KEY_LIST_URL, "").trim();
        long updated = settings.getLong(KEY_UPDATED, 0L);
        if (url.isEmpty() && n == 0) {
            statusText.setText("Configura la dirección de tu lista en Ajustes.");
        } else {
            statusText.setText(n + " enlaces · " + (updated > 0 ? "actualizada " + ago(updated) : "sin actualizar"));
        }
    }

    private String ago(long timestamp) {
        long minutes = (System.currentTimeMillis() - timestamp) / 60000L;
        if (minutes < 1) return "hace un momento";
        if (minutes < 60) return "hace " + minutes + " min";
        long hours = minutes / 60;
        if (hours < 24) return "hace " + hours + " h";
        return "hace " + (hours / 24) + " d";
    }

    // ------------------------------------------------------------------ Ajustes

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), dp(8));

        box.addView(label("Dirección de tu lista de enlaces (https://…)", 16, COLOR_MUTED, false));
        final EditText urlInput = makeInput("https://gist.githubusercontent.com/…/raw/enlaces.txt");
        urlInput.setText(settings.getString(KEY_LIST_URL, ""));
        box.addView(urlInput, topMargin(6));

        box.addView(label("Motor de Ace Stream (dirección:puerto). Normal: " + DEFAULT_ENGINE, 16, COLOR_MUTED, false), topMargin(16));
        final EditText engineInput = makeInput(DEFAULT_ENGINE);
        engineInput.setText(settings.getString(KEY_ENGINE, DEFAULT_ENGINE));
        box.addView(engineInput, topMargin(6));

        final CheckBox autoBox = new CheckBox(this);
        autoBox.setText("Comprobar los enlaces al abrir la app y al actualizar la lista");
        autoBox.setTextColor(COLOR_TEXT);
        autoBox.setChecked(settings.getBoolean(KEY_AUTO, true));
        autoBox.setFocusable(true);
        box.addView(autoBox, topMargin(16));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(scroll)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String engine = engineInput.getText().toString().trim();
                    settings.edit()
                            .putString(KEY_LIST_URL, urlInput.getText().toString().trim())
                            .putString(KEY_ENGINE, engine.isEmpty() ? DEFAULT_ENGINE : engine)
                            .putBoolean(KEY_AUTO, autoBox.isChecked())
                            .apply();
                    refreshStatusLine();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ------------------------------------------------------------------ Lista en línea

    private void autoStart() {
        if (!settings.getBoolean(KEY_AUTO, true)) return;
        if (!settings.getString(KEY_LIST_URL, "").trim().isEmpty()) {
            updateList(true, true);
        } else if (!listStore.load().isEmpty()) {
            startCheck(true);
        }
    }

    private void updateList(final boolean thenCheck, final boolean silent) {
        final String url = settings.getString(KEY_LIST_URL, "").trim();
        if (url.isEmpty()) {
            if (!silent) {
                toast("Primero escribe la dirección de tu lista.");
                showSettings();
            }
            return;
        }
        String low = url.toLowerCase(Locale.ROOT);
        if (!low.startsWith("http://") && !low.startsWith("https://")) {
            if (!silent) toast("La dirección debe empezar por https://");
            return;
        }
        if (checking) {
            if (!silent) toast("Primero para la comprobación que está en marcha.");
            return;
        }
        if (updating) return;

        updating = true;
        updateButton.setEnabled(false);
        statusText.setText("Actualizando lista…");

        // GitHub guarda las listas unos minutos en caché; este parámetro fuerza la versión más reciente.
        final String fetchUrl = url.contains("githubusercontent.com")
                ? url + (url.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis()
                : url;

        new Thread(() -> {
            String text = null;
            String error = null;
            try {
                text = Http.get(fetchUrl, 10000, 15000, 1000000, true);
            } catch (UnknownHostException e) {
                error = "Sin conexión a internet.";
            } catch (IOException e) {
                error = "No se pudo descargar la lista (" + e.getMessage() + ").";
            }
            final List<LinkStore.Item> parsed = text == null ? null : ListParser.parse(text);
            final String finalError = error;
            runOnUiThread(() -> onListDownloaded(parsed, finalError, thenCheck, silent));
        }).start();
    }

    private void onListDownloaded(List<LinkStore.Item> parsed, String error, boolean thenCheck, boolean silent) {
        updating = false;
        if (destroyed) return;
        updateButton.setEnabled(true);

        if (error != null) {
            statusText.setText(error);
            if (!silent) toast(error);
            return;
        }
        if (parsed == null || parsed.isEmpty()) {
            String msg = "La lista no tiene enlaces válidos. Se mantiene la anterior.";
            statusText.setText(msg);
            if (!silent) toast(msg);
            return;
        }

        listStore.replaceAll(parsed);
        Set<String> keys = new HashSet<>();
        for (LinkStore.Item item : parsed) keys.add(item.link.canonical());
        statusStore.keepOnly(keys);
        settings.edit().putLong(KEY_UPDATED, System.currentTimeMillis()).apply();

        refreshList();
        refreshStatusLine();
        if (thenCheck && settings.getBoolean(KEY_AUTO, true)) startCheck(silent);
    }

    // ------------------------------------------------------------------ Comprobación de enlaces

    private void startCheck(final boolean silent) {
        if (checking) return;
        final List<LinkStore.Item> items = listStore.load();
        if (items.isEmpty()) {
            if (!silent) toast("No hay enlaces en la lista. Pulsa «Actualizar lista» primero.");
            return;
        }
        final String base = EngineChecker.normalizeBase(settings.getString(KEY_ENGINE, DEFAULT_ENGINE));

        checking = true;
        checkCancelled = false;
        checkButton.setText("Parar comprobación");
        checkingKeys.clear();
        for (LinkStore.Item item : items) {
            String key = item.link.canonical();
            checkingKeys.add(key);
            setDot(dots.get(key), StatusStore.CHECKING);
        }
        statusText.setText("Comprobando 0/" + items.size() + "…");
        checkExecutor.execute(() -> runCheck(items, base, silent));
    }

    /** Se ejecuta en un hilo aparte; revisa los enlaces de uno en uno. */
    private void runCheck(final List<LinkStore.Item> items, final String base, final boolean silent) {
        boolean unavailable = !EngineChecker.reachable(base);
        int ok = 0;
        int down = 0;
        int done = 0;
        final int total = items.size();

        if (!unavailable) {
            for (LinkStore.Item item : items) {
                if (checkCancelled || destroyed) break;
                EngineChecker.Outcome outcome = EngineChecker.checkDetailed(item.link, base, CHECK_TIMEOUT_MS, () -> checkCancelled);
                EngineChecker.Result result = outcome.result;
                final Quality quality = outcome.quality;
                if (checkCancelled || destroyed) break;
                if (result == EngineChecker.Result.ENGINE_UNAVAILABLE) {
                    unavailable = true;
                    break;
                }
                done++;
                final int state;
                if (result == EngineChecker.Result.OK) {
                    ok++;
                    state = StatusStore.OK;
                } else {
                    down++;
                    state = StatusStore.DOWN;
                }
                final String key = item.link.canonical();
                final int doneNow = done;
                runOnUiThread(() -> {
                    if (destroyed) return;
                    if (quality != null) statusStore.putResult(key, state, quality);
                    else statusStore.put(key, state);
                    checkingKeys.remove(key);
                    setDot(dots.get(key), state);
                    statusText.setText("Comprobando " + doneNow + "/" + total + "…");
                });
            }
        }

        final boolean finalUnavailable = unavailable;
        final boolean finalCancelled = checkCancelled;
        final int finalOk = ok;
        final int finalDown = down;
        runOnUiThread(() -> finishCheck(finalUnavailable, finalCancelled, finalOk, finalDown, silent, base));
    }

    private void finishCheck(boolean unavailable, boolean cancelled, int ok, int down, boolean silent, String base) {
        checking = false;
        checkingKeys.clear();
        if (destroyed) return;

        // Lo que no se llegó a revisar vuelve a su color anterior.
        for (Map.Entry<String, View> entry : dots.entrySet()) {
            setDot(entry.getValue(), statusStore.get(entry.getKey()));
        }
        checkButton.setText("Comprobar enlaces");
        refreshList();   // reordena cada canal de mejor a peor con las notas nuevas

        if (unavailable) {
            statusText.setText("Motor de Ace Stream no disponible en " + base);
            if (!silent) showEngineMissingDialog(base);
        } else if (cancelled) {
            statusText.setText("Comprobación detenida · " + ok + " funcionan, " + down + " no");
        } else {
            statusText.setText("Comprobado · " + ok + " funcionan, " + down + " no");
        }
    }

    private void showEngineMissingDialog(String base) {
        new AlertDialog.Builder(this)
                .setTitle("No encuentro el motor de Ace Stream")
                .setMessage("Para comprobar los enlaces hace falta el motor de Ace Stream en " + base + ".\n\n"
                        + "Abre la app Ace Stream Media, déjala abierta unos segundos y vuelve a pulsar "
                        + "«Comprobar enlaces». Si usas el motor en otro equipo de tu red, cámbialo en Ajustes.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    /** Color del canal: naranja si se está revisando, verde si algún enlace funciona, rojo si todos caídos. */
    private int channelState(ChannelGrouper.Channel ch) {
        boolean anyOk = false;
        boolean allDown = true;
        for (LinkStore.Item it : ch.links) {
            int st = stateOf(it.link.canonical());
            if (st == StatusStore.CHECKING) return StatusStore.CHECKING;
            if (st == StatusStore.OK) anyOk = true;
            if (st != StatusStore.DOWN) allDown = false;
        }
        return anyOk ? StatusStore.OK : (allDown ? StatusStore.DOWN : StatusStore.UNKNOWN);
    }

    private int stateOf(String key) {
        return checkingKeys.contains(key) ? StatusStore.CHECKING : statusStore.get(key);
    }

    private void setDot(View dot, int state) {
        if (dot == null) return;
        int color;
        switch (state) {
            case StatusStore.OK:
                color = DOT_GREEN;
                break;
            case StatusStore.DOWN:
                color = DOT_RED;
                break;
            case StatusStore.CHECKING:
                color = DOT_ORANGE;
                break;
            default:
                color = DOT_GREY;
                break;
        }
        dot.setBackground(circle(color));
    }

    private GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    // ------------------------------------------------------------------ Reproducción

    private void play() {
        AceLink link = AceLink.parse(linkInput.getText().toString());
        if (link == null) {
            toast("Enlace no válido. Debe ser acestream://… o un ID de 40 caracteres.");
            linkInput.requestFocus();
            return;
        }
        recentStore.saveOrUpdate(link, nameInput.getText().toString());
        refreshList();
        launch(link);
    }

    private void launch(AceLink link) {
        Uri data;
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            data = Uri.parse("acestream:?content_id=" + link.value);
        } else {
            data = Uri.parse("acestream:?url=" + Uri.encode(link.value));
        }

        // Forma oficial (Ace Stream 3.1.43 o superior)
        Intent intent = new Intent("org.acestream.action.start_content");
        intent.setData(data);
        if (acePlayerCheck.isChecked()) {
            // 3 = reproductor integrado de Ace Stream (sin límite de tiempo)
            intent.putExtra("org.acestream.EXTRA_SELECTED_PLAYER", "{\"type\": 3}");
        }
        try {
            startActivity(intent);
            return;
        } catch (ActivityNotFoundException ignored) {
            // Se prueba el método antiguo.
        }

        // Versiones antiguas de Ace Stream: abrir directamente acestream://<id>
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("acestream://" + link.value)));
                return;
            } catch (ActivityNotFoundException ignored) {
                // No hay ninguna app que entienda acestream://
            }
        }
        showNotInstalledDialog();
    }

    private void showNotInstalledDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Falta Ace Stream Media")
                .setMessage("No he encontrado la app Ace Stream Media en esta televisión.\n\n"
                        + "Instálala desde la tienda de aplicaciones de tu tele (busca «Ace Stream Media») "
                        + "o con el APK oficial de acestream.org, y vuelve a pulsar Reproducir.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    // ------------------------------------------------------------------ Utilidades de diseño

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(size));
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText makeInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6F7C89);
        e.setTextColor(COLOR_TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(22));
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setImeOptions(EditorInfo.IME_ACTION_GO);
        e.setPadding(dp(16), dp(12), dp(16), dp(12));

        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(COLOR_SURFACE, COLOR_ACCENT, 3));
        bg.addState(new int[]{}, rounded(COLOR_SURFACE, 0xFF3A4856, 2));
        e.setBackground(bg);
        return e;
    }

    private Button makeButton(String text, int normalColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(COLOR_TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(20));
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setFocusable(true);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(56));
        b.setMinimumHeight(dp(56));
        b.setPadding(dp(20), dp(10), dp(20), dp(10));
        b.setBackground(focusBackground(normalColor));
        return b;
    }

    /** Fondo que se ilumina con borde blanco cuando el mando se coloca encima. */
    private StateListDrawable focusBackground(int normalColor) {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(COLOR_ACCENT, Color.WHITE, 3));
        bg.addState(new int[]{android.R.attr.state_pressed}, rounded(COLOR_ACCENT, Color.WHITE, 3));
        bg.addState(new int[]{}, rounded(normalColor, 0, 0));
        return bg;
    }

    private GradientDrawable rounded(int fill, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(10));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private LinearLayout.LayoutParams topMargin(int dpValue) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(dpValue);
        return p;
    }

    private int dp(int value) {
        return (int) (value * uiScale * getResources().getDisplayMetrics().density + 0.5f);
    }

    /** Tama\u00f1o de letra escalado. */
    private float sp(int value) {
        return value * uiScale;
    }
}
