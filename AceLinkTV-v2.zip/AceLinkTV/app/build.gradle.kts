plugins {
    id("com.android.application")
}

android {
    namespace = "com.acelink.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.acelink.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    // Firma fija (personal, solo para instalar en tus aparatos): hace que cada versión nueva
    // se pueda instalar encima de la anterior sin desinstalar.
    signingConfigs {
        create("acelink") {
            storeFile = file("acelink.jks")
            storePassword = "acelink123"
            keyAlias = "acelink"
            keyPassword = "acelink123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("acelink")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
// Sin dependencias externas: la app solo usa las librerías de Android.
