# AceLink para Android TV

App sencilla para Android TV / Google TV / Fire TV: escribes (o pegas) un enlace `acestream://…`
y se abre en **Ace Stream Media**, que es quien reproduce el vídeo. Guarda los enlaces recientes
para que no tengas que volver a escribirlos.

- Acepta `acestream://ID`, `acestream:?content_id=ID`, el ID suelto de 40 caracteres y
  direcciones `http://…` de archivos `.acelive` / `.torrent`.
- No incluye ningún canal ni lista de enlaces: los pones tú.
- App independiente, no afiliada a Ace Stream.

## Qué necesitas en la tele

1. Esta app (AceLink).
2. La app **Ace Stream Media** instalada en la misma tele (búscala en la tienda de aplicaciones
   de tu tele; si no aparece, el APK oficial está en acestream.org).

## 1. Conseguir el APK (se hace una sola vez, sin instalar nada en tu ordenador)

El APK se compila gratis en la nube de GitHub:

1. Crea una cuenta gratuita en <https://github.com>.
2. Pulsa **New repository**. Ponle de nombre `AceLinkTV` y déjalo **Public**
   (así podrás descargar el APK desde la tele con un enlace corto).
3. **Descomprime el zip** en tu ordenador (GitHub no descomprime zips). Dentro del repositorio
   nuevo pulsa **uploading an existing file** y arrastra **lo que hay dentro de la carpeta
   `AceLinkTV`** (las carpetas `app`, `gradle` y `.github`, y los archivos sueltos), no la carpeta
   `AceLinkTV` en sí: `.github` y `gradlew` tienen que quedar en la raíz del repositorio.
   La carpeta `.github` está oculta en Mac (se ve con Cmd + Mayús + punto).
   Si no consigues subirla, usa **Add file → Create new file**, escribe el nombre
   `.github/workflows/build-apk.yml` (las barras crean las carpetas) y pega el contenido de ese
   archivo. Pulsa **Commit changes**.
4. Abre la pestaña **Actions**. Verás una ejecución llamada *Compilar APK*; tarda unos 5 minutos.
   Cuando tenga el tic verde, el APK está listo.
5. Descárgalo desde **Releases** (columna derecha del repositorio) → `AceLink.apk`.

Si la compilación falla (cruz roja), abre la ejecución, copia el mensaje de error y me lo pasas.

## 2. Instalarlo en la tele

**Opción A: con la app «Downloader» (la más cómoda)**
1. Instala *Downloader* desde la tienda de la tele.
2. En los ajustes de la tele, permite a *Downloader* instalar apps desconocidas
   (Ajustes → Preferencias del dispositivo → Seguridad y restricciones → Orígenes desconocidos).
3. Abre *Downloader* y escribe:
   `https://github.com/TU_USUARIO/AceLinkTV/releases/latest/download/AceLink.apk`
   (cambia `TU_USUARIO` por tu nombre de usuario de GitHub) → Instalar.

**Opción B: con un pendrive USB**
Copia `AceLink.apk` a un USB, conéctalo a la tele y ábrelo con una app de archivos
(por ejemplo *X-plore* o *File Commander*).

**Opción C: con ADB (si ya lo usas)**
`adb connect IP_DE_LA_TELE` y después `adb install AceLink.apk`.

## 3. Uso

1. Abre **AceLink** desde la lista de aplicaciones de la tele.
2. Escribe o pega el enlace. Teclear 40 caracteres con el mando es lento: es mucho más cómodo
   usar la app **Google TV** (o *Android TV Remote*) del móvil, que permite escribir con el
   teclado del móvil, o un teclado Bluetooth.
3. Pulsa **Reproducir** (o Intro en el teclado). El enlace se guarda en *Recientes*.
4. Si marcas *Usar el reproductor de Ace Stream* (por defecto sí), la reproducción no tiene
   el límite de 5 minutos que Ace Stream aplica a reproductores externos.

## Compilar con Android Studio (alternativa)

Abre esta carpeta en Android Studio y elige **Build → Build APK(s)**. El archivo queda en
`app/build/outputs/apk/debug/app-debug.apk`.

## Estructura

- `app/src/main/java/com/acelink/tv/AceLink.java` — interpreta el enlace.
- `app/src/main/java/com/acelink/tv/LinkStore.java` — guarda los recientes.
- `app/src/main/java/com/acelink/tv/MainActivity.java` — pantalla y lanzamiento en Ace Stream.
- `.github/workflows/build-apk.yml` — compilación automática del APK.
