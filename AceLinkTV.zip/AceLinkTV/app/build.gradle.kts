plugins {
    id("com.android.application")
}

android {
    namespace = "com.acelink.tv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.acelink.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
// Sin dependencias externas: la app solo usa las librerías de Android.
