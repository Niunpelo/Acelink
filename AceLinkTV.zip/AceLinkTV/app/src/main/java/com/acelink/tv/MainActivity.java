package com.acelink.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Pantalla única: se escribe (o pega) un enlace acestream y se envía a Ace Stream Media,
 * que es la app que realmente se conecta a la red y reproduce el vídeo.
 *
 * La interfaz se construye por código para no depender de más archivos de diseño.
 */
public class MainActivity extends Activity {

    private static final int COLOR_BG = 0xFF0F141A;
    private static final int COLOR_SURFACE = 0xFF1C2630;
    private static final int COLOR_PRIMARY = 0xFF2E6FD8;
    private static final int COLOR_ACCENT = 0xFFFF8A1F;
    private static final int COLOR_TEXT = 0xFFFFFFFF;
    private static final int COLOR_MUTED = 0xFFA9B4C0;

    private static final String SETTINGS = "acelink_settings";
    private static final String KEY_USE_ACE_PLAYER = "use_ace_player";

    private LinkStore store;
    private SharedPreferences settings;

    private EditText linkInput;
    private EditText nameInput;
    private CheckBox acePlayerCheck;
    private LinearLayout listBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new LinkStore(this);
        settings = getSharedPreferences(SETTINGS, MODE_PRIVATE);
        setContentView(buildUi());
        refreshList();
    }

    // ------------------------------------------------------------------ Interfaz

    private LinearLayout buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(COLOR_BG);
        root.setPadding(dp(48), dp(32), dp(48), dp(32));

        // Columna izquierda: escribir el enlace
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        leftParams.rightMargin = dp(32);
        root.addView(left, leftParams);

        left.addView(label("AceLink", 36, COLOR_TEXT, true));
        left.addView(label("Escribe o pega un enlace acestream:// (o solo el ID de 40 caracteres).", 18, COLOR_MUTED, false), topMargin(8));

        linkInput = makeInput("acestream://…");
        linkInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                play();
                return true;
            }
            return false;
        });
        left.addView(linkInput, topMargin(24));

        nameInput = makeInput("Nombre (opcional)");
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        nameInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        nameInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                play();
                return true;
            }
            return false;
        });
        left.addView(nameInput, topMargin(12));

        Button playButton = makeButton("Reproducir", COLOR_PRIMARY);
        playButton.setGravity(Gravity.CENTER);
        playButton.setOnClickListener(v -> play());
        left.addView(playButton, topMargin(20));

        acePlayerCheck = new CheckBox(this);
        acePlayerCheck.setText("Usar el reproductor de Ace Stream (recomendado)");
        acePlayerCheck.setTextColor(COLOR_TEXT);
        acePlayerCheck.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        acePlayerCheck.setChecked(settings.getBoolean(KEY_USE_ACE_PLAYER, true));
        acePlayerCheck.setFocusable(true);
        acePlayerCheck.setBackground(focusBackground(0x00000000));
        acePlayerCheck.setPadding(dp(12), dp(10), dp(12), dp(10));
        acePlayerCheck.setOnCheckedChangeListener((buttonView, isChecked) ->
                settings.edit().putBoolean(KEY_USE_ACE_PLAYER, isChecked).apply());
        left.addView(acePlayerCheck, topMargin(16));

        left.addView(label("Necesitas tener instalada la app Ace Stream Media en esta televisión. "
                + "Si no la tienes, esta app te avisará.", 15, COLOR_MUTED, false), topMargin(16));

        // Columna derecha: enlaces recientes
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        root.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        right.addView(label("Recientes", 24, COLOR_TEXT, true));

        ScrollView scroll = new ScrollView(this);
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollParams.topMargin = dp(12);
        right.addView(scroll, scrollParams);

        return root;
    }

    private void refreshList() {
        listBox.removeAllViews();
        List<LinkStore.Item> items = store.load();
        if (items.isEmpty()) {
            listBox.addView(label("Aquí aparecerán los enlaces que reproduzcas.", 18, COLOR_MUTED, false));
            return;
        }
        for (final LinkStore.Item item : items) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            Button open = makeButton(item.label(), COLOR_SURFACE);
            open.setSingleLine(true);
            open.setEllipsize(android.text.TextUtils.TruncateAt.END);
            open.setOnClickListener(v -> launch(item.link));
            row.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button delete = makeButton("Borrar", COLOR_SURFACE);
            delete.setGravity(Gravity.CENTER);
            delete.setOnClickListener(v -> {
                store.remove(item.link);
                refreshList();
                focusFirstRowOrInput();
            });
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            deleteParams.leftMargin = dp(8);
            row.addView(delete, deleteParams);

            listBox.addView(row, topMargin(8));
        }
    }

    private void focusFirstRowOrInput() {
        if (listBox.getChildCount() > 0 && listBox.getChildAt(0) instanceof LinearLayout) {
            LinearLayout firstRow = (LinearLayout) listBox.getChildAt(0);
            if (firstRow.getChildCount() > 0 && firstRow.getChildAt(0).requestFocus()) return;
        }
        linkInput.requestFocus();
    }

    // ------------------------------------------------------------------ Reproducción

    private void play() {
        AceLink link = AceLink.parse(linkInput.getText().toString());
        if (link == null) {
            Toast.makeText(this,
                    "Enlace no válido. Debe ser acestream://… o un ID de 40 caracteres.",
                    Toast.LENGTH_LONG).show();
            linkInput.requestFocus();
            return;
        }
        store.saveOrUpdate(link, nameInput.getText().toString());
        refreshList();
        launch(link);
    }

    private void launch(AceLink link) {
        Uri data;
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            data = Uri.parse("acestream:?content_id=" + link.value);
        } else {
            data = Uri.parse("acestream:?url=" + Uri.encode(link.value));
        }

        // Forma oficial (Ace Stream 3.1.43 o superior)
        Intent intent = new Intent("org.acestream.action.start_content");
        intent.setData(data);
        if (acePlayerCheck.isChecked()) {
            // 3 = reproductor integrado de Ace Stream (sin límite de tiempo)
            intent.putExtra("org.acestream.EXTRA_SELECTED_PLAYER", "{\"type\": 3}");
        }
        try {
            startActivity(intent);
            return;
        } catch (ActivityNotFoundException ignored) {
            // Se prueba el método antiguo.
        }

        // Versiones antiguas de Ace Stream: abrir directamente acestream://<id>
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("acestream://" + link.value)));
                return;
            } catch (ActivityNotFoundException ignored) {
                // No hay ninguna app que entienda acestream://
            }
        }
        showNotInstalledDialog();
    }

    private void showNotInstalledDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Falta Ace Stream Media")
                .setMessage("No he encontrado la app Ace Stream Media en esta televisión.\n\n"
                        + "Instálala desde la tienda de aplicaciones de tu tele (busca «Ace Stream Media») "
                        + "o con el APK oficial de acestream.org, y vuelve a pulsar Reproducir.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    // ------------------------------------------------------------------ Utilidades de diseño

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText makeInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF6F7C89);
        e.setTextColor(COLOR_TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setImeOptions(EditorInfo.IME_ACTION_GO);
        e.setPadding(dp(16), dp(12), dp(16), dp(12));

        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(COLOR_SURFACE, COLOR_ACCENT, 3));
        bg.addState(new int[]{}, rounded(COLOR_SURFACE, 0xFF3A4856, 2));
        e.setBackground(bg);
        return e;
    }

    private Button makeButton(String text, int normalColor) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(COLOR_TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setFocusable(true);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(56));
        b.setMinimumHeight(dp(56));
        b.setPadding(dp(20), dp(10), dp(20), dp(10));
        b.setBackground(focusBackground(normalColor));
        return b;
    }

    /** Fondo que se ilumina con borde naranja cuando el mando se coloca encima. */
    private StateListDrawable focusBackground(int normalColor) {
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(COLOR_ACCENT, Color.WHITE, 3));
        bg.addState(new int[]{android.R.attr.state_pressed}, rounded(COLOR_ACCENT, Color.WHITE, 3));
        bg.addState(new int[]{}, rounded(normalColor, 0, 0));
        return bg;
    }

    private GradientDrawable rounded(int fill, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(10));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private LinearLayout.LayoutParams topMargin(int dpValue) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(dpValue);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
