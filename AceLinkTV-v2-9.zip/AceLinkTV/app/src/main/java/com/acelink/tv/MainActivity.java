package com.acelink.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pantalla única:
 *  - izquierda: escribir un enlace a mano y reproducirlo, y los ajustes;
 *  - derecha: "Mi lista" (descargada de tu dirección en línea, con un círculo de color que indica
 *    si cada enlace funciona) y "Recientes".
 *
 * La reproducción la hace la app Ace Stream Media; la comprobación usa su motor local.
 * La interfaz se construye por código para no depender de más archivos de diseño.
 */
public class MainActivity extends Activity {

    // Tema "Oro sobre negro": fondo casi negro, superficies suaves, un solo acento champán.
    private static final int COLOR_BG = 0xFF0A0A0C;
    private static final int COLOR_SURFACE = 0xFF141418;
    private static final int COLOR_SURFACE_FOCUS = 0xFF1B1B21;
    private static final int COLOR_LINE = 0xFF24242B;
    private static final int COLOR_PRIMARY = 0xFFC9A96E;       // botones principales (champán)
    private static final int COLOR_PRIMARY_FOCUS = 0xFFDEC48F;
    private static final int COLOR_ON_PRIMARY = 0xFF15120B;
    private static final int COLOR_ACCENT = 0xFFC9A96E;
    private static final int COLOR_TEXT = 0xFFF3F3F5;
    private static final int COLOR_MUTED = 0xFF8D8D98;
    private static final int COLOR_HINT = 0xFF5E5E69;

    private static final int DOT_GREY = 0xFF52525C;
    private static final int DOT_GREEN = 0xFF4CC38A;
    private static final int DOT_RED = 0xFFE5605F;
    private static final int DOT_ORANGE = 0xFFE6AE3F;

    private static final String SETTINGS = "acelink_settings";
    private static final String KEY_USE_ACE_PLAYER = "use_ace_player";
    private static final String KEY_LIST_URL = "list_url";
    private static final String KEY_ENGINE = "engine";
    private static final String KEY_AUTO = "auto_check";
    private static final String KEY_UPDATED = "list_updated";

    private static final String DEFAULT_ENGINE = "127.0.0.1:6878";
    private static final long CHECK_TIMEOUT_MS = 25000;

    private LinkStore recentStore;
    private LinkStore listStore;
    private StatusStore statusStore;
    private SharedPreferences settings;

    private EditText linkInput;
    private EditText nameInput;
    private CheckBox acePlayerCheck;
    private LinearLayout listBox;
    private TextView statusText;
    private Button updateButton;
    private Button checkButton;
    /** Botón «Comprobar canal» de la carpeta abierta (null si no hay carpeta abierta). */
    private Button folderCheckButton;

    /** Círculo de color de cada enlace de "Mi lista", por enlace normalizado. */
    private final Map<String, View> dots = new HashMap<>();
    /** Enlaces que están pendientes de revisar o revisándose ahora (círculo naranja). */
    private final Set<String> checkingKeys = new HashSet<>();
    /** Carpeta (canal) abierta ahora mismo; null = se ve la lista de canales. */
    private String openChannel;
    /** Círculo de cada canal en la lista principal, por clave de canal. */
    private final Map<String, View> chDots = new HashMap<>();
    private final Map<String, ChannelGrouper.Channel> channelByKey = new HashMap<>();
    /** Texto de estado/calidad y pastilla de nota de cada enlace (dentro de una carpeta), por enlace. */
    private final Map<String, TextView> detailViews = new HashMap<>();
    private final Map<String, TextView> chipViews = new HashMap<>();
    /** Pastilla de nota de cada canal en la lista principal, por clave de canal. */
    private final Map<String, TextView> chChips = new HashMap<>();
    /** Clave de canal al que pertenece cada enlace. */
    private final Map<String, String> linkChannel = new HashMap<>();

    private final ExecutorService checkExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean checkCancelled;
    private volatile boolean destroyed;
    private boolean checking;
    private boolean updating;

    /** Factor de escala de la interfaz (1 = televisi\u00f3n normal; menos en pantallas peque\u00f1as). */
    private float uiScale = 1f;
    /** Pantalla ancha pero baja (m\u00f3vil en horizontal): se quitan textos de ayuda para que todo quepa. */
    private boolean compact;
    /** Móvil en vertical: textos más cortos y leyenda en dos filas. */
    private boolean narrowLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recentStore = new LinkStore(this);
        listStore = new LinkStore(this, "acelink_list", 500);
        statusStore = new StatusStore(this);
        settings = getSharedPreferences(SETTINGS, MODE_PRIVATE);
        getWindow().setStatusBarColor(COLOR_BG);
        getWindow().setNavigationBarColor(COLOR_BG);
        setContentView(buildUi());
        refreshList();
        refreshStatusLine();
        autoStart();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        checkCancelled = true;
        checkExecutor.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ Interfaz

    private View buildUi() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float widthDp = dm.widthPixels / dm.density;
        float heightDp = dm.heightPixels / dm.density;
        boolean narrow = widthDp < 700f;
        // Pantalla ancha: se reduce todo en proporción si es más pequeña que una tele (960 x 540 dp).
        uiScale = narrow ? 1f : Math.max(0.7f, Math.min(1f, Math.min(heightDp / 540f, widthDp / 960f)));
        compact = !narrow && uiScale < 0.85f;
        narrowLayout = narrow;

        // Una sola columna: título, la lista y, debajo, añadir enlace y ajustes.
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(narrow ? 16 : 48), dp(narrow ? 20 : 32), dp(narrow ? 16 : 48), dp(40));

        TextView appTitle = label("AceLink", 36, COLOR_TEXT, true);
        appTitle.setLetterSpacing(0.03f);
        column.addView(appTitle);
        column.addView(buildRightPanel(false), topMargin(16));

        View divider = new View(this);
        divider.setBackgroundColor(COLOR_LINE);
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        dividerParams.topMargin = dp(36);
        dividerParams.bottomMargin = dp(28);
        column.addView(divider, dividerParams);

        column.addView(buildLeftPanel());

        ScrollView page = new ScrollView(this);
        page.setBackgroundColor(COLOR_BG);
        // En pantallas anchas la columna no se estira: se queda centrada y legible.
        int maxWidth = Math.min(dm.widthPixels, dp(860));
        page.addView(column, new FrameLayout.LayoutParams(
                maxWidth, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL));
        return page;
    }

    /** Escribir el enlace, reproducir y ajustes. */
    private LinearLayout buildLeftPanel() {
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);

        left.addView(label("Añadir enlace", 22, COLOR_TEXT, true));
        if (!compact) {
            left.addView(label("Escribe o pega un enlace acestream:// (o solo el ID de 40 caracteres).", 16, COLOR_MUTED, false), topMargin(6));
        }

        linkInput = makeInput("acestream://\u2026");
        linkInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                play();
                return true;
            }
            return false;
        });
        left.addView(linkInput, topMargin(16));

        nameInput = makeInput("Nombre (opcional)");
        nameInput.setInputType(InputType.TYPE_CLASS_TEXT);
        nameInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        nameInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_GO) {
                play();
                return true;
            }
            return false;
        });
        left.addView(nameInput, topMargin(12));

        Button playButton = makeButton("Reproducir", COLOR_PRIMARY);
        playButton.setGravity(Gravity.CENTER);
        playButton.setOnClickListener(v -> play());
        left.addView(playButton, topMargin(20));

        acePlayerCheck = new CheckBox(this);
        acePlayerCheck.setText("Usar el reproductor de Ace Stream (recomendado)");
        acePlayerCheck.setTextColor(COLOR_TEXT);
        acePlayerCheck.setButtonTintList(ColorStateList.valueOf(COLOR_ACCENT));
        acePlayerCheck.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(18));
        acePlayerCheck.setChecked(settings.getBoolean(KEY_USE_ACE_PLAYER, true));
        acePlayerCheck.setFocusable(true);
        acePlayerCheck.setBackground(focusBackground(0x00000000));
        acePlayerCheck.setPadding(dp(12), dp(10), dp(12), dp(10));
        acePlayerCheck.setOnCheckedChangeListener((buttonView, isChecked) ->
                settings.edit().putBoolean(KEY_USE_ACE_PLAYER, isChecked).apply());
        left.addView(acePlayerCheck, topMargin(16));

        Button settingsButton = makeButton("Ajustes de la lista y del motor", COLOR_SURFACE);
        settingsButton.setOnClickListener(v -> showSettings());
        left.addView(settingsButton, topMargin(16));

        if (!compact) {
            left.addView(label("Necesitas tener instalada la app Ace Stream Media en esta televisi\u00f3n. "
                    + "Si no la tienes, esta app te avisar\u00e1.", 15, COLOR_MUTED, false), topMargin(16));
        }
        return left;
    }

    /** Mi lista (con c\u00edrculos de color) y Recientes. */
    private LinearLayout buildRightPanel(boolean listScrollsInside) {
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        right.addView(label("Mi lista", 24, COLOR_TEXT, true));
        statusText = label("", 15, COLOR_MUTED, false);
        right.addView(statusText, topMargin(4));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setBaselineAligned(false);
        updateButton = makeButton("Actualizar lista", COLOR_PRIMARY);
        updateButton.setGravity(Gravity.CENTER);
        updateButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(narrowLayout ? 16 : 17));
        updateButton.setSingleLine(true);
        updateButton.setOnClickListener(v -> updateList(true, false));
        actions.addView(updateButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        checkButton = makeButton("Comprobar enlaces", COLOR_SURFACE);
        checkButton.setGravity(Gravity.CENTER);
        checkButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(narrowLayout ? 16 : 17));
        checkButton.setSingleLine(true);
        checkButton.setOnClickListener(v -> {
            if (checking) {
                checkCancelled = true;
                statusText.setText("Parando\u2026");
            } else {
                startCheck(false);
            }
        });
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        checkParams.leftMargin = dp(8);
        actions.addView(checkButton, checkParams);
        right.addView(actions, topMargin(12));

        LinearLayout legend = new LinearLayout(this);
        legend.setOrientation(narrowLayout ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        legend.setGravity(Gravity.CENTER_VERTICAL);
        if (narrowLayout) {
            LinearLayout r1 = new LinearLayout(this);
            LinearLayout r2 = new LinearLayout(this);
            r1.setGravity(Gravity.CENTER_VERTICAL);
            r2.setGravity(Gravity.CENTER_VERTICAL);
            addLegendItem(r1, DOT_GREEN, "Funciona");
            addLegendItem(r1, DOT_RED, "No funciona");
            addLegendItem(r2, DOT_ORANGE, "Revisando");
            addLegendItem(r2, DOT_GREY, "Sin revisar");
            legend.addView(r1);
            legend.addView(r2, topMargin(6));
        } else {
            addLegendItem(legend, DOT_GREEN, "Funciona");
            addLegendItem(legend, DOT_RED, "No funciona");
            addLegendItem(legend, DOT_ORANGE, "Revisando");
            addLegendItem(legend, DOT_GREY, "Sin revisar");
        }
        right.addView(legend, topMargin(12));

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        if (listScrollsInside) {
            ScrollView scroll = new ScrollView(this);
            scroll.addView(listBox, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            scrollParams.topMargin = dp(12);
            right.addView(scroll, scrollParams);
        } else {
            right.addView(listBox, topMargin(12));
        }
        return right;
    }

    private void addLegendItem(LinearLayout legend, int color, String text) {
        View dot = new View(this);
        dot.setBackground(circle(color));
        LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(dp(12), dp(12));
        dotParams.rightMargin = dp(6);
        legend.addView(dot, dotParams);
        TextView t = label(text, 14, COLOR_MUTED, false);
        t.setSingleLine(true);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textParams.rightMargin = dp(16);
        legend.addView(t, textParams);
    }

    private void refreshList() {
        listBox.removeAllViews();
        dots.clear();
        folderCheckButton = null;
        chDots.clear();
        detailViews.clear();
        chipViews.clear();
        chChips.clear();
        channelByKey.clear();
        linkChannel.clear();

        List<LinkStore.Item> mine = listStore.load();
        List<ChannelGrouper.Channel> channels = ChannelGrouper.group(mine, statusStore);
        for (ChannelGrouper.Channel ch : channels) {
            channelByKey.put(ch.key, ch);
            for (LinkStore.Item it : ch.links) linkChannel.put(it.link.canonical(), ch.key);
        }

        if (openChannel != null && channelByKey.containsKey(openChannel)) {
            buildFolder(channelByKey.get(openChannel));
            return;
        }
        openChannel = null;

        listBox.addView(label("Mi lista (" + channels.size() + " canales · " + mine.size() + " enlaces)",
                20, COLOR_TEXT, true));
        if (mine.isEmpty()) {
            listBox.addView(label("Todavía no hay enlaces. Escribe la dirección de tu lista en Ajustes "
                    + "y pulsa «Actualizar lista».", 16, COLOR_MUTED, false), topMargin(8));
        }
        for (final ChannelGrouper.Channel ch : channels) {
            final int n = ch.links.size();
            LinearLayout card = makeCard();
            if (n > 1) {
                card.setOnClickListener(v -> {
                    openChannel = ch.key;
                    refreshList();
                    focusFirstRowOrInput();
                });
            } else {
                card.setOnClickListener(v -> launch(ch.best().link));
            }

            View chDot = new View(this);
            setDot(chDot, channelState(ch));
            chDots.put(ch.key, chDot);
            addDot(card, chDot);

            TextView name = label(ch.name, 20, COLOR_TEXT, false);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            card.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            if (n > 1) {
                TextView cnt = label(n + (narrowLayout ? "" : " enlaces"), 15, COLOR_MUTED, false);
                card.addView(cnt, rightGap(12));
            }
            TextView chip = scoreChip(channelScore(ch));
            chChips.put(ch.key, chip);
            card.addView(chip, rightGap(n > 1 ? 10 : 0));
            if (n > 1) card.addView(label("›", 26, COLOR_MUTED, false));
            listBox.addView(card, topMargin(8));
        }

        List<LinkStore.Item> recents = recentStore.load();
        if (!recents.isEmpty()) {
            listBox.addView(label("Recientes", 20, COLOR_TEXT, true), topMargin(24));
        }
        for (final LinkStore.Item item : recents) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            Button open = makeButton(item.label(), COLOR_SURFACE);
            open.setSingleLine(true);
            open.setEllipsize(android.text.TextUtils.TruncateAt.END);
            open.setOnClickListener(v -> launch(item.link));
            row.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            Button delete = makeButton("Borrar", COLOR_SURFACE);
            delete.setGravity(Gravity.CENTER);
            delete.setOnClickListener(v -> {
                recentStore.remove(item.link);
                refreshList();
                focusFirstRowOrInput();
            });
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            deleteParams.leftMargin = dp(8);
            row.addView(delete, deleteParams);

            listBox.addView(row, topMargin(8));
        }
    }

    /** Pantalla de una carpeta: volver, reproducir el mejor y todos los enlaces de mejor a peor. */
    private void buildFolder(final ChannelGrouper.Channel ch) {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        Button back = makeButton("‹   Volver", COLOR_SURFACE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> closeFolder());
        top.setBaselineAligned(false);
        top.addView(back, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        folderCheckButton = makeButton(checking ? "Parar" : "Comprobar canal", COLOR_SURFACE);
        folderCheckButton.setGravity(Gravity.CENTER);
        folderCheckButton.setSingleLine(true);
        folderCheckButton.setOnClickListener(v -> {
            if (checking) {
                checkCancelled = true;
                statusText.setText("Parando…");
            } else {
                startCheck(new ArrayList<>(ch.links), false);   // solo los enlaces de esta carpeta
            }
        });
        LinearLayout.LayoutParams folderCheckParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        folderCheckParams.leftMargin = dp(12);
        top.addView(folderCheckButton, folderCheckParams);
        listBox.addView(top);

        listBox.addView(label(ch.name, 30, COLOR_TEXT, true), topMargin(16));
        listBox.addView(label(ch.links.size() + " enlaces · ordenados de mejor a peor",
                15, COLOR_MUTED, false), topMargin(4));

        for (final LinkStore.Item item : ch.links) {
            final String key = item.link.canonical();
            LinearLayout card = makeCard();
            card.setOnClickListener(v -> launch(item.link));

            View dot = new View(this);
            setDot(dot, stateOf(key));
            dots.put(key, dot);
            addDot(card, dot);

            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            TextView l1 = label(linkTitle(ch, item), 19, COLOR_TEXT, false);
            l1.setSingleLine(true);
            l1.setEllipsize(android.text.TextUtils.TruncateAt.END);
            txt.addView(l1);

            TextView l2 = label(linkDetail(key), 13, COLOR_MUTED, false);
            detailViews.put(key, l2);
            txt.addView(l2, topMargin(2));
            card.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView chip = scoreChip(okScore(key));
            chipViews.put(key, chip);
            card.addView(chip, rightGap(0));
            listBox.addView(card, topMargin(8));
        }
    }

    /** Fila tipo tarjeta: se enfoca con el mando y se ilumina con borde de acento. */
    private LinearLayout makeCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setFocusable(true);
        c.setClickable(true);
        c.setMinimumHeight(dp(64));
        c.setPadding(dp(20), dp(10), dp(18), dp(10));
        c.setBackground(focusBackground(COLOR_SURFACE));
        return c;
    }

    private void addDot(LinearLayout card, View dot) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(14), dp(14));
        lp.rightMargin = dp(16);
        card.addView(dot, lp);
    }

    private LinearLayout.LayoutParams rightGap(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(leftDp);
        return lp;
    }

    /** Pastilla con la nota, p. ej. "★ 94", en el color de acento. Oculta si score < 0. */
    private TextView scoreChip(int score) {
        TextView t = label("", 14, COLOR_ACCENT, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x24C9A96E);
        d.setCornerRadius(dp(20));
        t.setBackground(d);
        t.setPadding(dp(12), dp(4), dp(12), dp(4));
        setChip(t, score);
        return t;
    }

    private void setChip(TextView chip, int score) {
        if (score >= 0) {
            chip.setText("★ " + score);
            chip.setVisibility(View.VISIBLE);
        } else {
            chip.setVisibility(View.GONE);
        }
    }

    /** Nota del enlace si funciona y tiene medidas; -1 si no. */
    private int okScore(String key) {
        return statusStore.get(key) == StatusStore.OK ? statusStore.getScore(key) : -1;
    }

    /** Mejor nota entre los enlaces del canal que funcionan; -1 si ninguno. */
    private int channelScore(ChannelGrouper.Channel ch) {
        int best = -1;
        for (LinkStore.Item it : ch.links) best = Math.max(best, okScore(it.link.canonical()));
        return best;
    }

    /** Línea gris bajo el enlace: calidad medida, o su estado. */
    private String linkDetail(String key) {
        if (checkingKeys.contains(key)) return "Revisando…";
        int st = statusStore.get(key);
        if (st == StatusStore.OK) {
            String d = statusStore.detail(key);
            return d.isEmpty() ? "Funciona · vuelve a comprobar para ver la calidad" : d;
        }
        return st == StatusStore.DOWN ? "No funciona" : "Sin revisar";
    }

    /** Nombre corto del enlace dentro de su carpeta: "Movistar Laliga op.2" -> "op.2". */
    private String linkTitle(ChannelGrouper.Channel ch, LinkStore.Item item) {
        String full = item.label();
        if (full.length() > ch.name.length() && full.regionMatches(true, 0, ch.name, 0, ch.name.length())) {
            String rest = full.substring(ch.name.length()).replaceAll("^[\\s\\-–—:(\\[]+|[)\\]\\s]+$", "");
            if (!rest.isEmpty()) return rest;
        }
        return full;
    }

    private void closeFolder() {
        openChannel = null;
        refreshList();
        focusFirstRowOrInput();
    }

    @Override
    public void onBackPressed() {
        if (openChannel != null) {
            closeFolder();
        } else {
            super.onBackPressed();
        }
    }

    /** Actualiza al momento el círculo del enlace y el de su canal (se ve mientras se comprueba). */
    private void updateDots(String linkKey) {
        setDot(dots.get(linkKey), stateOf(linkKey));
        TextView detail = detailViews.get(linkKey);
        if (detail != null) detail.setText(linkDetail(linkKey));
        TextView chip = chipViews.get(linkKey);
        if (chip != null) setChip(chip, okScore(linkKey));
        String ck = linkChannel.get(linkKey);
        if (ck == null) return;
        ChannelGrouper.Channel ch = channelByKey.get(ck);
        if (ch != null) {
            setDot(chDots.get(ck), channelState(ch));
            TextView chChip = chChips.get(ck);
            if (chChip != null) setChip(chChip, channelScore(ch));
        }
    }

    private void focusFirstRowOrInput() {
        for (int i = 0; i < listBox.getChildCount(); i++) {
            View child = listBox.getChildAt(i);
            if (child instanceof LinearLayout) {
                LinearLayout row = (LinearLayout) child;
                if (row.isFocusable() && row.requestFocus()) return;
                for (int j = 0; j < row.getChildCount(); j++) {
                    if (row.getChildAt(j) instanceof Button && row.getChildAt(j).requestFocus()) return;
                }
            }
        }
        linkInput.requestFocus();
    }

    private void refreshStatusLine() {
        int n = listStore.load().size();
        String url = settings.getString(KEY_LIST_URL, "").trim();
        long updated = settings.getLong(KEY_UPDATED, 0L);
        if (url.isEmpty() && n == 0) {
            statusText.setText("Configura la dirección de tu lista en Ajustes.");
        } else {
            statusText.setText(n + " enlaces · " + (updated > 0 ? "actualizada " + ago(updated) : "sin actualizar"));
        }
    }

    private String ago(long timestamp) {
        long minutes = (System.currentTimeMillis() - timestamp) / 60000L;
        if (minutes < 1) return "hace un momento";
        if (minutes < 60) return "hace " + minutes + " min";
        long hours = minutes / 60;
        if (hours < 24) return "hace " + hours + " h";
        return "hace " + (hours / 24) + " d";
    }

    // ------------------------------------------------------------------ Ajustes

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(8), dp(24), dp(8));

        box.addView(label("Dirección de tu lista de enlaces (https://…)", 16, COLOR_MUTED, false));
        final EditText urlInput = makeInput("https://gist.githubusercontent.com/…/raw/enlaces.txt");
        urlInput.setText(settings.getString(KEY_LIST_URL, ""));
        box.addView(urlInput, topMargin(6));

        box.addView(label("Motor de Ace Stream (dirección:puerto). Normal: " + DEFAULT_ENGINE, 16, COLOR_MUTED, false), topMargin(16));
        final EditText engineInput = makeInput(DEFAULT_ENGINE);
        engineInput.setText(settings.getString(KEY_ENGINE, DEFAULT_ENGINE));
        box.addView(engineInput, topMargin(6));

        final CheckBox autoBox = new CheckBox(this);
        autoBox.setText("Comprobar los enlaces al abrir la app y al actualizar la lista");
        autoBox.setTextColor(COLOR_TEXT);
        autoBox.setButtonTintList(ColorStateList.valueOf(COLOR_ACCENT));
        autoBox.setChecked(settings.getBoolean(KEY_AUTO, true));
        autoBox.setFocusable(true);
        box.addView(autoBox, topMargin(16));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        showStyled(new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setView(scroll)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String engine = engineInput.getText().toString().trim();
                    settings.edit()
                            .putString(KEY_LIST_URL, urlInput.getText().toString().trim())
                            .putString(KEY_ENGINE, engine.isEmpty() ? DEFAULT_ENGINE : engine)
                            .putBoolean(KEY_AUTO, autoBox.isChecked())
                            .apply();
                    refreshStatusLine();
                })
                .setNegativeButton("Cancelar", null)
                );
    }

    // ------------------------------------------------------------------ Lista en línea

    private void autoStart() {
        if (!settings.getBoolean(KEY_AUTO, true)) return;
        if (!settings.getString(KEY_LIST_URL, "").trim().isEmpty()) {
            updateList(true, true);
        } else if (!listStore.load().isEmpty()) {
            startCheck(true);
        }
    }

    private void updateList(final boolean thenCheck, final boolean silent) {
        final String url = settings.getString(KEY_LIST_URL, "").trim();
        if (url.isEmpty()) {
            if (!silent) {
                toast("Primero escribe la dirección de tu lista.");
                showSettings();
            }
            return;
        }
        String low = url.toLowerCase(Locale.ROOT);
        if (!low.startsWith("http://") && !low.startsWith("https://")) {
            if (!silent) toast("La dirección debe empezar por https://");
            return;
        }
        if (checking) {
            if (!silent) toast("Primero para la comprobación que está en marcha.");
            return;
        }
        if (updating) return;

        updating = true;
        updateButton.setEnabled(false);
        statusText.setText("Actualizando lista…");

        // GitHub guarda las listas unos minutos en caché; este parámetro fuerza la versión más reciente.
        final String fetchUrl = url.contains("githubusercontent.com")
                ? url + (url.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis()
                : url;

        new Thread(() -> {
            String text = null;
            String error = null;
            try {
                text = Http.get(fetchUrl, 10000, 15000, 1000000, true);
            } catch (UnknownHostException e) {
                error = "Sin conexión a internet.";
            } catch (IOException e) {
                error = "No se pudo descargar la lista (" + e.getMessage() + ").";
            }
            final List<LinkStore.Item> parsed = text == null ? null : ListParser.parse(text);
            final String finalError = error;
            runOnUiThread(() -> onListDownloaded(parsed, finalError, thenCheck, silent));
        }).start();
    }

    private void onListDownloaded(List<LinkStore.Item> parsed, String error, boolean thenCheck, boolean silent) {
        updating = false;
        if (destroyed) return;
        updateButton.setEnabled(true);

        if (error != null) {
            statusText.setText(error);
            if (!silent) toast(error);
            return;
        }
        if (parsed == null || parsed.isEmpty()) {
            String msg = "La lista no tiene enlaces válidos. Se mantiene la anterior.";
            statusText.setText(msg);
            if (!silent) toast(msg);
            return;
        }

        listStore.replaceAll(parsed);
        Set<String> keys = new HashSet<>();
        for (LinkStore.Item item : parsed) keys.add(item.link.canonical());
        statusStore.keepOnly(keys);
        settings.edit().putLong(KEY_UPDATED, System.currentTimeMillis()).apply();

        refreshList();
        refreshStatusLine();
        if (thenCheck && settings.getBoolean(KEY_AUTO, true)) startCheck(silent);
    }

    // ------------------------------------------------------------------ Comprobación de enlaces

    private void startCheck(final boolean silent) {
        startCheck(listStore.load(), silent);
    }

    /** Comprueba los enlaces dados (toda la lista, o solo los de una carpeta). */
    private void startCheck(final List<LinkStore.Item> items, final boolean silent) {
        if (checking) return;
        if (items.isEmpty()) {
            if (!silent) toast("No hay enlaces en la lista. Pulsa «Actualizar lista» primero.");
            return;
        }
        final String base = EngineChecker.normalizeBase(settings.getString(KEY_ENGINE, DEFAULT_ENGINE));

        checking = true;
        checkCancelled = false;
        checkButton.setText(narrowLayout ? "Parar" : "Parar comprobación");
        if (folderCheckButton != null) folderCheckButton.setText("Parar");
        checkingKeys.clear();
        for (LinkStore.Item item : items) {
            String key = item.link.canonical();
            checkingKeys.add(key);
        }
        for (LinkStore.Item item : items) updateDots(item.link.canonical());
        statusText.setText("Comprobando 0/" + items.size() + "…");
        checkExecutor.execute(() -> runCheck(items, base, silent));
    }

    /** Se ejecuta en un hilo aparte; revisa los enlaces de uno en uno. */
    private void runCheck(final List<LinkStore.Item> items, final String base, final boolean silent) {
        boolean unavailable = !EngineChecker.reachable(base);
        int ok = 0;
        int down = 0;
        int done = 0;
        final int total = items.size();

        if (!unavailable) {
            for (LinkStore.Item item : items) {
                if (checkCancelled || destroyed) break;
                EngineChecker.Outcome outcome = EngineChecker.checkDetailed(item.link, base, CHECK_TIMEOUT_MS, () -> checkCancelled);
                EngineChecker.Result result = outcome.result;
                final Quality quality = outcome.quality;
                if (checkCancelled || destroyed) break;
                if (result == EngineChecker.Result.ENGINE_UNAVAILABLE) {
                    unavailable = true;
                    break;
                }
                done++;
                final int state;
                if (result == EngineChecker.Result.OK) {
                    ok++;
                    state = StatusStore.OK;
                } else {
                    down++;
                    state = StatusStore.DOWN;
                }
                final String key = item.link.canonical();
                final int doneNow = done;
                runOnUiThread(() -> {
                    if (destroyed) return;
                    if (quality != null) statusStore.putResult(key, state, quality);
                    else statusStore.put(key, state);
                    checkingKeys.remove(key);
                    updateDots(key);
                    statusText.setText("Comprobando " + doneNow + "/" + total + "…");
                });
            }
        }

        final boolean finalUnavailable = unavailable;
        final boolean finalCancelled = checkCancelled;
        final int finalOk = ok;
        final int finalDown = down;
        runOnUiThread(() -> finishCheck(finalUnavailable, finalCancelled, finalOk, finalDown, silent, base));
    }

    private void finishCheck(boolean unavailable, boolean cancelled, int ok, int down, boolean silent, String base) {
        checking = false;
        checkingKeys.clear();
        if (destroyed) return;

        // Lo que no se llegó a revisar vuelve a su color anterior.
        for (Map.Entry<String, View> entry : dots.entrySet()) {
            setDot(entry.getValue(), statusStore.get(entry.getKey()));
        }
        checkButton.setText("Comprobar enlaces");
        refreshList();   // reordena cada canal de mejor a peor con las notas nuevas

        if (unavailable) {
            statusText.setText("Motor de Ace Stream no disponible en " + base);
            if (!silent) showEngineMissingDialog(base);
        } else if (cancelled) {
            statusText.setText("Comprobación detenida · " + ok + " funcionan, " + down + " no");
        } else {
            statusText.setText("Comprobado · " + ok + " funcionan, " + down + " no");
        }
    }

    private void showEngineMissingDialog(String base) {
        showStyled(new AlertDialog.Builder(this)
                .setTitle("No encuentro el motor de Ace Stream")
                .setMessage("Para comprobar los enlaces hace falta el motor de Ace Stream en " + base + ".\n\n"
                        + "Abre la app Ace Stream Media, déjala abierta unos segundos y vuelve a pulsar "
                        + "«Comprobar enlaces». Si usas el motor en otro equipo de tu red, cámbialo en Ajustes.")
                .setPositiveButton("Entendido", null)
                );
    }

    /** Color del canal: verde si algún enlace funciona; si no, naranja si queda alguno por revisar; rojo si todos caídos. */
    private int channelState(ChannelGrouper.Channel ch) {
        boolean anyOk = false;
        boolean anyChecking = false;
        boolean allDown = true;
        for (LinkStore.Item it : ch.links) {
            int st = stateOf(it.link.canonical());
            if (st == StatusStore.OK) anyOk = true;
            if (st == StatusStore.CHECKING) anyChecking = true;
            if (st != StatusStore.DOWN) allDown = false;
        }
        if (anyOk) return StatusStore.OK;
        if (anyChecking) return StatusStore.CHECKING;
        return allDown ? StatusStore.DOWN : StatusStore.UNKNOWN;
    }

    private int stateOf(String key) {
        return checkingKeys.contains(key) ? StatusStore.CHECKING : statusStore.get(key);
    }

    private void setDot(View dot, int state) {
        if (dot == null) return;
        int color;
        switch (state) {
            case StatusStore.OK:
                color = DOT_GREEN;
                break;
            case StatusStore.DOWN:
                color = DOT_RED;
                break;
            case StatusStore.CHECKING:
                color = DOT_ORANGE;
                break;
            default:
                color = DOT_GREY;
                break;
        }
        dot.setBackground(circle(color));
    }

    private GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    // ------------------------------------------------------------------ Reproducción

    private void play() {
        AceLink link = AceLink.parse(linkInput.getText().toString());
        if (link == null) {
            toast("Enlace no válido. Debe ser acestream://… o un ID de 40 caracteres.");
            linkInput.requestFocus();
            return;
        }
        recentStore.saveOrUpdate(link, nameInput.getText().toString());
        refreshList();
        launch(link);
    }

    private void launch(AceLink link) {
        Uri data;
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            data = Uri.parse("acestream:?content_id=" + link.value);
        } else {
            data = Uri.parse("acestream:?url=" + Uri.encode(link.value));
        }

        // Forma oficial (Ace Stream 3.1.43 o superior)
        Intent intent = new Intent("org.acestream.action.start_content");
        intent.setData(data);
        if (acePlayerCheck.isChecked()) {
            // 3 = reproductor integrado de Ace Stream (sin límite de tiempo)
            intent.putExtra("org.acestream.EXTRA_SELECTED_PLAYER", "{\"type\": 3}");
        }
        try {
            startActivity(intent);
            return;
        } catch (ActivityNotFoundException ignored) {
            // Se prueba el método antiguo.
        }

        // Versiones antiguas de Ace Stream: abrir directamente acestream://<id>
        if (link.kind == AceLink.Kind.CONTENT_ID) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("acestream://" + link.value)));
                return;
            } catch (ActivityNotFoundException ignored) {
                // No hay ninguna app que entienda acestream://
            }
        }
        showNotInstalledDialog();
    }

    private void showNotInstalledDialog() {
        showStyled(new AlertDialog.Builder(this)
                .setTitle("Falta Ace Stream Media")
                .setMessage("No he encontrado la app Ace Stream Media en esta televisión.\n\n"
                        + "Instálala desde la tienda de aplicaciones de tu tele (busca «Ace Stream Media») "
                        + "o con el APK oficial de acestream.org, y vuelve a pulsar Reproducir.")
                .setPositiveButton("Entendido", null)
                );
    }

    // ------------------------------------------------------------------ Utilidades de diseño

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(size));
        t.setTextColor(color);
        // Títulos grandes en peso ligero (elegante); subtítulos en peso medio.
        if (bold) t.setTypeface(Typeface.create(size >= 24 ? "sans-serif-light" : "sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private EditText makeInput(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(COLOR_HINT);
        e.setTextColor(COLOR_TEXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(22));
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setImeOptions(EditorInfo.IME_ACTION_GO);
        e.setPadding(dp(22), dp(16), dp(22), dp(16));

        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(COLOR_SURFACE_FOCUS, COLOR_ACCENT, 2));
        bg.addState(new int[]{}, rounded(COLOR_SURFACE, COLOR_LINE, 1));
        e.setBackground(bg);
        return e;
    }

    private Button makeButton(String text, int normalColor) {
        Button b = new Button(this);
        boolean primary = normalColor == COLOR_PRIMARY;
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(primary ? COLOR_ON_PRIMARY : COLOR_TEXT);
        b.setTypeface(Typeface.create(primary ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp(20));
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setFocusable(true);
        b.setStateListAnimator(null);
        b.setMinHeight(dp(60));
        b.setMinimumHeight(dp(60));
        b.setPadding(dp(24), dp(12), dp(24), dp(12));
        b.setBackground(focusBackground(normalColor));
        return b;
    }

    /** Fondo suave con borde fino; al enfocar con el mando se ilumina con un borde de acento. */
    private StateListDrawable focusBackground(int normalColor) {
        boolean primary = normalColor == COLOR_PRIMARY;
        int focusFill = primary ? COLOR_PRIMARY_FOCUS : COLOR_SURFACE_FOCUS;
        int focusStroke = primary ? Color.WHITE : COLOR_ACCENT;
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, rounded(focusFill, focusStroke, 2));
        bg.addState(new int[]{android.R.attr.state_pressed}, rounded(focusFill, focusStroke, 2));
        bg.addState(new int[]{}, rounded(normalColor, normalColor == COLOR_SURFACE ? COLOR_LINE : 0,
                normalColor == COLOR_SURFACE ? 1 : 0));
        return bg;
    }

    private GradientDrawable rounded(int fill, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(16));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    /** Texto con el nombre normal, un dato en gris pequeño y una nota en el color de acento. */
    private CharSequence rowText(String name, String meta, String rating) {
        SpannableStringBuilder sb = new SpannableStringBuilder(name);
        if (meta != null && !meta.isEmpty()) {
            int st = sb.length();
            sb.append("   ").append(meta);
            sb.setSpan(new ForegroundColorSpan(COLOR_MUTED), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new RelativeSizeSpan(0.82f), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (rating != null && !rating.isEmpty()) {
            int st = sb.length();
            sb.append("   ").append(rating);
            sb.setSpan(new ForegroundColorSpan(COLOR_ACCENT), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new RelativeSizeSpan(0.88f), st, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return sb;
    }

    /** Aplica fondo oscuro y bordes suaves a los cuadros de diálogo. */
    private void showStyled(AlertDialog.Builder builder) {
        AlertDialog dialog = builder.create();
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(rounded(COLOR_SURFACE, COLOR_LINE, 1));
        }
    }

    private LinearLayout.LayoutParams topMargin(int dpValue) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(dpValue);
        return p;
    }

    private int dp(int value) {
        return (int) (value * uiScale * getResources().getDisplayMetrics().density + 0.5f);
    }

    /** Tama\u00f1o de letra escalado. */
    private float sp(int value) {
        return value * uiScale;
    }
}
