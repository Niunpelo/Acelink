# AceLink para Android TV (versión 2.9)

App sencilla para Android TV / Google TV / Fire TV: escribes (o eliges de tu lista) un enlace
`acestream://…` y se abre en **Ace Stream Media**, que es quien reproduce el vídeo.

Novedades de la versión 2.9:

- **Nuevo orden de la pantalla (una sola columna):** arriba el título y los botones de actualizar/comprobar,
  después la lista de canales y, **debajo de la lista**, «Añadir enlace» y los ajustes.
- **Botón «Comprobar canal» dentro de cada carpeta:** comprueba solo los enlaces de esa carpeta (y se
  convierte en «Parar» mientras trabaja). Al terminar se reordenan de mejor a peor.

Novedades de la versión 2.8:

- **Calidad en vivo:** el texto bajo cada enlace («94/100 · 2,5 s · 35 peers · 900 KB/s» o «No funciona») y la
  pastilla ★ se actualizan al instante mientras se comprueba, aunque tengas la carpeta abierta.
  Mientras espera su turno pone «Revisando…».
- Sin los números #1, #2… en la carpeta (el orden de mejor a peor se mantiene; se reordena al terminar
  la comprobación). La pastilla del canal muestra la mejor nota de sus enlaces.

Novedades de la versión 2.7:

- **Agrupa también `op.2`, `op 3`, `op4`, `opc. 2`…:** «Movistar Laliga op.1», «Movistar Laliga op.2»… van
  todos a la carpeta «Movistar Laliga». Un número que forma parte del canal («Laliga 2») se respeta.
- **Filas como en el diseño:** pastilla `★ 94` a la derecha de cada canal y de cada enlace, contador de
  enlaces y flecha `›` en las carpetas. Dentro de la carpeta cada enlace se muestra con su nombre corto («op.2»).
- **Móvil en vertical:** la leyenda de colores va en dos filas y los botones de arriba ya no se cortan.
  (La nota aparece cuando termina la comprobación de ese enlace.)

Novedades de la versión 2.6:

- **Tema premium minimalista «Oro sobre negro»:** fondo casi negro, superficies suaves con borde fino,
  un único acento champán, tipografía ligera, círculos de estado más finos y notas (★) en el color de acento.
  Los colores están todos al principio de `MainActivity.java` (`COLOR_ACCENT`, `COLOR_PRIMARY`…): para
  probar la variante «Hielo» (azul), cambia `0xFFC9A96E` por `0xFF8FB4FF` en `COLOR_PRIMARY` y
  `COLOR_ACCENT`, y `0xFFDEC48F` por `0xFFB3CEFF` en `COLOR_PRIMARY_FOCUS`.

Novedades de la versión 2.3:

- **Canales con varios enlaces:** los enlaces con el mismo nombre se agrupan en un solo canal.
  Si un canal tiene varios enlaces aparece como una **carpeta 📁**: entras, ves todos sus enlaces
  de mejor a peor (el primero con ★ si funciona) y pulsas el que quieras. Con el botón Atrás o
  «Volver» sales de la carpeta. Los canales con un solo enlace se reproducen directamente.
- **Colores en vivo:** el círculo de cada canal y de cada enlace cambia mientras se comprueba
  (naranja = revisando, verde = funciona, rojo = no funciona). El de una carpeta se pone verde en cuanto
  uno de sus enlaces funciona.
- **Nota de calidad (0-100)** de cada enlace, y orden de mejor a peor dentro de cada canal
  (funcionan > sin revisar > caídos). Se recalcula al pulsar **Comprobar enlaces**.

Dos formas de agrupar (mira `enlaces-ejemplo.txt`):

```
## DAZN 1
acestream://ID_1
Fuente 2 | acestream://ID_2
##
DAZN 2 | acestream://ID_3
```

La forma `## Canal` es la más segura: todos los enlaces de debajo son de ese canal, pase lo que pase con
sus nombres. La otra forma es que los nombres coincidan. En la lista principal, junto al canal se ve
la nota del mejor enlace (★ 82) una vez comprobado.

Cómo se agrupa por nombre: se ignoran mayúsculas, tildes, lo que va entre paréntesis o corchetes y etiquetas
como HD, FHD, 1080p, «opción 2», «fuente 3», «backup». Así, `DAZN 1`, `DAZN 1 HD` y
`DAZN 1 (Fuente 2)` son el mismo canal, pero `DAZN 2` es otro.

Cómo se puntúa (solo enlaces que funcionan; datos del motor Ace Stream, 5 muestras de 1 s):

| Parámetro | Puntos | Máximo cuando… |
|---|---|---|
| Tiempo de arranque | 35 | ≤ 3 s (0 puntos a los 20 s) |
| Velocidad media de descarga | 30 | ≥ 1000 KB/s |
| Peers conectados | 20 | ≥ 40 |
| Estabilidad (mínima / media) | 15 | la velocidad no cae |

La nota se suaviza con la anterior (60 % nueva, 40 % antigua) para que una prueba suelta
no cambie el orden de golpe. Es una medida desde tu conexión y en ese momento: repite la
comprobación antes de ver un evento.

Novedades de la versión 2:

- **Mi lista en línea:** los enlaces viven en un archivo de texto tuyo (un Gist de GitHub) que
  editas desde el ordenador o el móvil. En la app pulsas **Actualizar lista** y se descargan.
- **Comprobación de enlaces:** un círculo junto a cada enlace: verde = funciona, rojo = no funciona,
  naranja = revisando, gris = sin revisar.
- **Firma fija:** las actualizaciones se instalan encima de la anterior, sin desinstalar
  (solo hay que desinstalar la versión 1 una vez, porque tenía otra firma).

La app no incluye ningún canal ni lista de enlaces: los pones tú. App independiente, no afiliada a Ace Stream.

## Formato de tu lista

Un archivo de texto, una línea por enlace (mira `enlaces-ejemplo.txt`):

```
Nombre del canal | acestream://ID_DE_40_CARACTERES
```

También vale `acestream://ID Nombre`, `Nombre - acestream://ID`, el ID suelto y listas M3U.
Las líneas que empiezan por `#` son comentarios.

## Crear tu lista (una vez)

1. Entra en <https://gist.github.com> con tu cuenta (sirve en ordenador y móvil).
2. Nombre del archivo: `enlaces.txt`. Escribe tus enlaces con el formato de arriba.
3. Pulsa **Create secret gist** (secreto: solo lo ve quien tenga la dirección).
4. En el gist pulsa **Raw** y copia la dirección. Será como
   `https://gist.githubusercontent.com/USUARIO/ID/raw/CODIGO_LARGO/enlaces.txt`.
   **Borra la parte `CODIGO_LARGO/`**, para que quede `…/raw/enlaces.txt` y apunte siempre
   a la última versión.
5. Para cambiar la lista: abre el gist, **Edit**, guarda. En la tele pulsa **Actualizar lista**.

## En la app

1. **Ajustes de la lista y del motor** → pega la dirección de tu lista → Guardar.
2. **Actualizar lista** descarga los enlaces (se guardan en la tele, así que sin internet
   se sigue viendo la última lista).
3. **Comprobar enlaces** revisa uno a uno con el motor de Ace Stream. Para esto hace falta que la app
   **Ace Stream Media esté abierta** (el motor escucha en `127.0.0.1:6878`; si lo usas en otro equipo,
   cambia la dirección en Ajustes). Cada enlace se revisa hasta 25 segundos.
4. Pulsa un enlace para reproducirlo.

## Conseguir el APK

El APK se compila gratis en GitHub (ver `.github/workflows/build-apk.yml`): sube el zip a tu
repositorio y la compilación arranca sola; el APK queda en **Releases**.
Alternativa: abrir esta carpeta en Android Studio y elegir **Build → Build APK(s)**.

## Estructura

- `MainActivity.java` — pantalla, ajustes, lista y círculos.
- `AceLink.java` — interpreta un enlace.
- `ListParser.java` — lee tu archivo de lista.
- `EngineChecker.java` — comprueba un enlace con el motor de Ace Stream y mide su calidad.
- `Quality.java` — fórmula de la nota. `ChannelName.java` y `ChannelGrouper.java` — agrupan y ordenan.
- `Http.java`, `LinkStore.java`, `StatusStore.java` — descarga y almacenamiento local.
- `app/acelink.jks` — firma fija personal para poder actualizar la app (no es secreta).
