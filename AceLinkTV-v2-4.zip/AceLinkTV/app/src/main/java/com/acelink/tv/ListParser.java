package com.acelink.tv;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Lee el archivo de texto con tu lista de enlaces. Una línea por enlace. Formatos válidos:
 *
 *   Nombre del canal | acestream://ID
 *   acestream://ID | Nombre del canal
 *   acestream://ID Nombre del canal
 *   Nombre del canal - acestream://ID
 *   ID de 40 caracteres
 *   #EXTINF:-1,Nombre            (listas M3U: el nombre va en la línea anterior al enlace)
 *   acestream://ID
 *
 * Las líneas vacías y las que empiezan por # o // se ignoran (sirven de comentarios).
 * No depende de Android, así que se puede probar con Java normal.
 */
final class ListParser {

    private static final Pattern EDGE_JUNK = Pattern.compile("^[\\s\\-–—:,;]+|[\\s\\-–—:,;]+$");

    private ListParser() {
    }

    static List<LinkStore.Item> parse(String text) {
        List<LinkStore.Item> out = new ArrayList<>();
        if (text == null) return out;
        Set<String> seen = new HashSet<>();
        String pendingName = "";

        for (String raw : text.replace("﻿", "").split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;

            if (line.regionMatches(true, 0, "#EXTINF", 0, 7)) {
                int comma = line.lastIndexOf(',');
                pendingName = comma >= 0 ? line.substring(comma + 1).trim() : "";
                continue;
            }
            if (line.startsWith("#") || line.startsWith("//")) continue;

            String name = "";
            AceLink link = null;

            int bar = line.indexOf('|');
            if (bar >= 0) {
                String left = line.substring(0, bar).trim();
                String right = line.substring(bar + 1).trim();
                AceLink fromRight = AceLink.parse(right);
                AceLink fromLeft = AceLink.parse(left);
                if (fromRight != null) {
                    link = fromRight;
                    name = left;
                } else if (fromLeft != null) {
                    link = fromLeft;
                    name = right;
                }
            }

            if (link == null) {
                String[] tokens = line.split("\\s+");
                int found = findToken(tokens, true);
                if (found < 0) found = findToken(tokens, false);
                if (found >= 0) {
                    link = AceLink.parse(tokens[found]);
                    StringBuilder rest = new StringBuilder();
                    for (int i = 0; i < tokens.length; i++) {
                        if (i == found) continue;
                        if (rest.length() > 0) rest.append(' ');
                        rest.append(tokens[i]);
                    }
                    name = rest.toString();
                }
            }

            if (link == null) {
                pendingName = "";
                continue;
            }

            name = EDGE_JUNK.matcher(name).replaceAll("").trim();
            if (name.isEmpty()) name = pendingName;
            pendingName = "";

            if (seen.add(link.canonical())) out.add(new LinkStore.Item(name, link));
        }
        return out;
    }

    /** Busca el primer trozo de la línea que sea un enlace; primero prueba solo con IDs. */
    private static int findToken(String[] tokens, boolean onlyContentIds) {
        for (int i = 0; i < tokens.length; i++) {
            AceLink l = AceLink.parse(tokens[i]);
            if (l == null) continue;
            if (onlyContentIds && l.kind != AceLink.Kind.CONTENT_ID) continue;
            return i;
        }
        return -1;
    }
}
